function YellowCar(){
	this.x = 2* width / 3;
	this.y = height - 50;
	this.speed = 0.5;

	this.showVertical = function(){
		stroke(255,223,0);
  		fill(255,223,0);
  		rect(this.x, this.y, 30, 40);
  		ellipse(this.x + 15.5 , this.y, 30 ,20 );
  		ellipse(this.x + 15.5, this.y + 40, 30 ,20 );

  		fill(0,0,0);
  		stroke(192, 192, 192);
  		rect(this.x + 30, this.y + 5, 5, 10);
  		rect(this.x + 30, this.y + 25, 5, 10);
  		rect(this.x - 5 , this.y + 5, 5, 10);
  		rect(this.x - 5, this.y + 25, 5, 10);
	}

	this.showHorizontal = function(){
		stroke(255,223,0);
  		fill(255,223,0);
  		rect(this.x, this.y, 40, 30);
  		ellipse(this.x  , this.y + 15.5, 20 ,30 );
  		ellipse(this.x + 40, this.y + 15.5, 20 ,30 );

  		fill(0,0,0);
  		stroke(192, 192, 192);
  		rect(this.x + 30, this.y - 5, 10, 5);
  		rect(this.x + 30, this.y + 30, 10, 5);
  		rect(this.x  , this.y - 5, 10, 5);
  		rect(this.x, this.y + 30, 10, 5);
	}

	this.dir = function(x, y){
		this.x += x * this.speed;
		this.y += y * this.speed;
	}

	this.update = function(){
		this.x = constrain(this.x, 10, width - 50);
    this.y = constrain(this.y,10,height - 50);
	}

	this.Up = function(pos){
var d = dist(this.x, this.y, pos.x, pos.y);
    if (d < 50) {
      return true;
    } else {
      return false;
    }
}
}


function BlueCar(){
	this.x = width / 3;
	this.y = height - 50;
	this.speed = 0.5;

	this.showVertical = function(){
		stroke(0,102,204);
  		fill(0,102,204);
  		rect(this.x, this.y, 30, 40);
  		ellipse(this.x + 15.5 , this.y, 30 ,20 );
  		ellipse(this.x + 15.5, this.y + 40, 30 ,20 );

  		fill(0,0,0);
  		stroke(192, 192, 192);
  		rect(this.x + 30, this.y + 5, 5, 10);
  		rect(this.x + 30, this.y + 25, 5, 10);
  		rect(this.x - 5 , this.y + 5, 5, 10);
  		rect(this.x - 5, this.y + 25, 5, 10);
	}

	this.update = function(){
		this.x = constrain(this.x, 10, width - 50);
    this.y = constrain(this.y,10,height - 50);
	}

	this.showHorizontal = function(){
		stroke(0,102,204);
  		fill(0,102,204);
  		rect(this.x, this.y, 40, 30);
  		ellipse(this.x  , this.y + 15.5, 20 ,30 );
  		ellipse(this.x + 40, this.y + 15.5, 20 ,30 );

  		fill(0,0,0);
  		stroke(192, 192, 192);
  		rect(this.x + 30, this.y - 5, 10, 5);
  		rect(this.x + 30, this.y + 30, 10, 5);
  		rect(this.x  , this.y - 5, 10, 5);
  		rect(this.x, this.y + 30, 10, 5);
	}

	this.dir = function(x, y){
		this.x += x * this.speed;
		this.y += y * this.speed;
	}

	this.Up = function(pos){
var d = dist(this.x, this.y, pos.x, pos.y);
    if (d < 50) {
      return true;
    } else {
      return false;
    }
}
}


