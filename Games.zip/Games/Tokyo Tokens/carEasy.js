
function CarLeft(size) {
  this.size = size;
  this.x = - this.size;
  this.y = floor(random(30)) * 20;
  
  this.xspeed = random(0.5, 3);
  this.yspeed = 0;

this.update = function() {
    this.x = this.x + this.xspeed * scl;
    this.y = this.y + this.yspeed * scl;
    if (this.x > width)
    {this.x = -this.size;}
  }

this.show = function() {
fill(255, 0, 100);
ellipse(this.x, this.y, this.size, this.size);
	}
this.kill = function(Car){
if (Car.y + 40 >= this.y && Car.y <= this.y + this.size  && (Car.x - 10 <= this.x &&  Car.x + 50 >= this.x + this.size)) 
{
  if (window.confirm("Wanna Play Again?")) {
	setup();}
  else{window.close();}
}
}
}

function CarRight(size) {
  this.size = size;
  this.x = width + this.size;
  this.y = floor(random(30)) * 10;
  
  this.xspeed = -random(0.5, 3);
  this.yspeed = 0;

this.update = function() {
    this.x = this.x + this.xspeed * scl;
    this.y = this.y + this.yspeed * scl;
    if (this.x < - this.size)
    {this.x = width + this.size;}
  }

this.show = function() {
fill(255, 0, 100);
ellipse(this.x, this.y, this.size, this.size);
  }
this.kill = function(Car){
if (Car.y + 40 >= this.y && Car.y <= this.y + this.size  && (Car.x - 10 <= this.x &&  Car.x + 50 >= this.x + this.size)) 
{
  if (window.confirm("Wanna Play Again?")) {
  setup();}
  else{window.close();}
}
}
}


