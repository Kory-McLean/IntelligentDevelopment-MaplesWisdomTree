var ding = new Audio("DING.mp3");
var scl = 20;
var YC;
var BC;
var BCScore;
var YCScore;
var BCView;
var YCView;
var cars;
var c;

function setup(){
  createCanvas(850, 850);
  placeLifeUp();
  YC = new YellowCar();
  BC = new BlueCar();
  YCScore = 0;
  BCScore = 0;
  frameRate(10);
  c = new CarLeft(random(5, 40));
  cars = [c];
  YCView = 1;
  BCView = 1;
}

function draw(){
  background(51);
  if (YC.Up(t)) 
    {
      YC.speed += 0.25;
      ding.play();
      AddCar();
    placeLifeUp();}
  else if (BC.Up(t)){
    BC.speed += 0.25;
    ding.play();
    AddCar();
    placeLifeUp();
  }
  if (YCView === 1){
    YC.showVertical();
  }
  else{YC.showHorizontal();}
  YMove();

  if (BCView === 1){
    BC.showVertical();
  }
  else{BC.showHorizontal();}
  BMove();
  YC.update();
  BC.update();
  drivecars();
  buildBoard();

}

function drivecars(){
  for (var i = 0; i < cars.length; i++) {
    cars[i].update();
    cars[i].show();
    cars[i].kill(YC);
    cars[i].kill(BC);
}
}


function BMove(){
if (keyIsDown(87)) {
    BCView = 1;
    BC.dir(0, -20);
  } 
  else if (keyIsDown(83)) {
    BCView = 1;
    BC.dir(0, 20);
  } 
  else if (keyIsDown(68)) {
    BCView = 0;
    BC.dir(20, 0);
  } 
  else if (keyIsDown(65)) {
    BCView = 0;
    BC.dir(-20, 0);
  }
}

function AddCar(){
  if (cars.length % 2 === 0){
    var newCr = new CarRight(random(5, 40));
    cars.push(newCr);}
    else{
      var newCl = new CarLeft(random(5, 40));
    cars.push(newCl);
    }
}

function YMove() {

  if (keyIsDown(UP_ARROW)) {
    YCView = 1;
    YC.dir(0, -20);
  } 
  else if (keyIsDown(DOWN_ARROW)) {
    YCView = 1;
    YC.dir(0, 20);
  } 
  else if (keyIsDown(RIGHT_ARROW)) {
    YCView = 0;
    YC.dir(20, 0);
  } 
  else if (keyIsDown(LEFT_ARROW)) {
    YCView = 0;
    YC.dir(-20, 0);
  }
}

function buildBoard(){
  fill(255,128,0);
  ellipse(t.x + 10, t.y + 10, 20, 20);
  fill(255,255,0);
  ellipse(t.x + 10, t.y + 10, 10, 10);
} 

function placeLifeUp() {
  var cols = floor(width/scl);
  var rows = floor(height/scl);
  t = createVector(floor(random(cols)), floor(random(rows)));
  t.mult(scl);
}

