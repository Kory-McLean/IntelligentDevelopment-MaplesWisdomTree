var gulp = new Audio('frog sound effect.mp3');

function Frog() {
  this.x = (width / 2) - scl;
  this.y = (height) - scl;
  this.belly = 0;

this.dir = function(x, y) {
this.x += x;
this.y += y;
}

this.show = function() {
    
   fill(0,255,0);
   rect(this.x, this.y, 4, 4);
   rect(this.x , this.y + 16, 4, 4);
   rect(this.x + 4 ,this.y + 4, 12, 12);
   rect(this.x + 16, this.y, 4, 4);
   rect(this.x + 16, this.y + 16, 4, 4);
    
  }

  this.eat = function(pos) {
    var d = dist(this.x, this.y, pos.x, pos.y);
    if (d < 5) {
      gulp.play();
      return true;
    } else {
      return false;
    }
  }

  this.update = function() {
    this.x = constrain(this.x, 0, width - scl);
    this.y = constrain(this.y, 0, height - scl);

  }

}
