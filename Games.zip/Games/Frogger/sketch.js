var tiger = new Audio('Survivor - Eye Of The Tiger.mp3');
tiger.loop = true;
var f;
var c;
var t;
var cars;
var scl = 20;
var person;
var scoreboard = [];
function setup() {
  tiger.play();
  person = prompt("Please enter your name");
  canvas = createCanvas(600, 600);
  f = new Frog();
  c = new CarLeft(random(40, 100));
  cars = [c];
  frameRate(10);
  placetoken();
}

function drivecars(){
  for (var i = 0; i < cars.length; i++) {
  	cars[i].update();
  	cars[i].show();
  	cars[i].kill();
  };
}

function placetoken() {
  var cols = floor(width/scl);
  var rows = floor(height/scl);
  t = createVector(floor(random(cols)), floor(random(rows)));
  t.mult(scl);
}

function draw() {
    background(51);
    if (f.eat(t)) 
    {
    placetoken();
    if (f.belly % 2 === 0){
    var newCr = new CarRight(random(40, 100));
    cars.push(newCr);}
    else{
      var newCl = new CarLeft(random(40, 100));
    cars.push(newCl);
    }
    f.belly ++;
	}

  f.update();
  f.show();
 drivecars();

  fill(255,223,0);
  ellipse(t.x + 10, t.y + 10, scl, scl);
}

function keyPressed() {

  if (keyCode === UP_ARROW) {
    f.dir(0, -20);
  } 
  else if (keyCode === DOWN_ARROW) {
    f.dir(0, 20);
  } 
  else if (keyCode === RIGHT_ARROW) {
    f.dir(20, 0);
  } 
  else if (keyCode === LEFT_ARROW) {
    f.dir(-20, 0);
  }
}

$('body').find('img').addClass('Frog');