var audio = new Audio('Car Tire Screech Sound Effect.mp3');


function CarLeft(size) {
  this.size = size;
  this.x = - this.size;
  this.y = floor(random(30)) * 20;
  
  this.xspeed = random(0.5, 3);
  this.yspeed = 0;

this.update = function() {
    this.x = this.x + this.xspeed * scl;
    this.y = this.y + this.yspeed * scl;
    if (this.x > width)
    {this.x = -this.size;}
  }

this.show = function() {
fill(255, 0, 100);
rect(this.x, this.y, this.size, scl);
	}
this.kill = function(){
if (f.y === this.y && (f.x >= this.x &&  f.x <= this.x + this.size)) 
{
  audio.play();
	window.alert("You Died...Your Score: " + f.belly);
   if (person != null && person !== "")
   {
    scoreboard.push([person, f.belly]);
  scoreboard.sort[function(a){return a[1]}];
  }
  sortScores(scoreboard);
  window.alert("Highscores: \n" + displayScore());
  if (window.confirm("Wanna Play Again?")) {
	setup();}
  else{window.close();}
}
}
}

function CarRight(size) {
  this.size = size;
  this.x = width + this.size;
  this.y = floor(random(30)) * 20;
  
  this.xspeed = -random(0.5, 3);
  this.yspeed = 0;

this.update = function() {
    this.x = this.x + this.xspeed * scl;
    this.y = this.y + this.yspeed * scl;
    if (this.x < - this.size)
    {this.x = width + this.size;}
  }

this.show = function() {
fill(255, 0, 100);
rect(this.x, this.y, this.size, scl);
  }
this.kill = function(){
if (f.y === this.y && (f.x >= this.x &&  f.x <= this.x + this.size)) 
{
  audio.play();
  window.alert("You Died " + person + "...Your Score: " + f.belly);
   if (person != null && person !== "")
   {
    scoreboard.push([person, f.belly]);
  scoreboard.sort[function(a){return a[1]}];
  }
  sortScores(scoreboard);
  window.alert("Highscores: \n" + displayScore());
    if (window.confirm("Wanna Play Again?")) {
  setup();}
  else{window.close();}
}
}
}
function displayScore(){
  var result = "";
  for (var i = 0; i < scoreboard.length; i++) {
      result += scoreboard[i][0] + ": " + scoreboard[i][1] + "\n";
    };
  return result;
}

function sortScores(arr){
  arr.sort((function(index){
    return function(a, b){
        return (a[index] === b[index] ? 0 : (a[index] > b[index] ? -1 : 1));
    };
})(1));
}

