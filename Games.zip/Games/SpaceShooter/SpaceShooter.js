var blaster = new Audio("laser.mp3");

function YellowSpaceship(){
  this.x = (width / 2) - scl;
  this.y = (height) - 15;
  this.barrelx = this.x + 20;
  this.barrely = this.y - 25;


this.show = function(){
  if (YSLife >= 5)
    {
      stroke(255,153,51);
      fill(51);
      ellipse(this.x + 20 , this.y - 3 , 100, 100)
    }
  stroke(255,223,0);
  fill(255,223,0);
  //body
   rect(this.x, this.y, scl *2, 15);
   rect(this.x + 5, this.y - 5, scl* 2 - 10, 5);
    rect(this.x + 10, this.y - scl, scl* 2 - 20, 15);

    fill(204,255,255);
    rect(this.x + 15, this.y - 10, 10, 5);

    fill(255,223,0);
   //wing
   rect(this.x - 15, this.y + 5, 15, 5);
   rect(this.x + scl* 2, this.y + 5, 15, 5);
   //wing 
   rect(this.x + scl*2 + 15, this.y - 5, 5, 15);
   rect(this.x - 15 - 5 , this.y - 5, 5, 15);
   //barrel
    rect(this.x + 15, this.y - 40, scl* 2 - 30, 20);


} 

this.dir = function(x, y) {
this.x += x;
this.y += y;
this.barrelx = this.x + 20;
this.barrely = this.y - 25;
}

this.update = function() {
  this.reload();
    this.x = constrain(this.x, 40, width - 60);
    this.y = constrain(this.y,height/2 + 50,height - 15);
  }

this.shoot = function(){
 if (YSClip > 0){
  blaster.play();
 var newShot = new YMissle(this.barrelx, this.barrely);
    bullets.push(newShot);
    YSClip -= 1;}
}

this.reload = function(){
  if (this.x === (width / 2) - scl && this.y === (height) - 15 && YSClip === 0)
  {
    YSClip = 10;
  }
}

this.Up = function(pos){
var d = dist(this.x, this.y, pos.x, pos.y);
var barrelD = dist(this.barrelx, this.barrely, pos.x, pos.y);
    if (d < 50 || barrelD < 10) {
      return true;
    } else {
      return false;
    }
}

}


//BLUE SHIP



function BlueSpaceship(){
  this.x = (width / 2) - scl;
  this.y = 0;
  this.barrelx = this.x + 20;
  this.barrely = this.y + 40;

this.show = function(){
  if (BSLife >= 5)
    {
      stroke(255,153,51);
      fill(51);
      ellipse(this.x + 20 , this.y + 20 , 100, 100)
    }
    stroke(0,102,204);
  fill(0,102,204);
  //body
   rect(this.x, this.y , scl *2, 15);
   rect(this.x + 5, this.y + 15, scl* 2 - 10, 5);
    rect(this.x + 10, this.y +scl, scl* 2 - 20, 15);

    fill(204,255,255);
    rect(this.x + 15, this.y + 20, 10, 5);


    fill(0,102,204);
   //wing
   rect(this.x - 15, this.y + 5, 15, 5);
   rect(this.x + scl* 2, this.y + 5, 15, 5);
   //wing 
   rect(this.x + scl*2 + 15, this.y + 5, 5, 15);
   rect(this.x - 15 - 5 , this.y + 5, 5, 15);
   //barrel
    rect(this.x + 15, this.y + 35, scl* 2 - 30, 20);

} 

this.dir = function(x, y) {
this.x += x;
this.y += y;
this.barrelx = this.x + 20;
this.barrely = this.y + 40;
}

this.update = function() {
  this.reload();
    this.x = constrain(this.x, 40, width - 60);
    this.y = constrain(this.y,0,height/2 - 65);
  }

this.shoot = function(){
 if ( BSClip > 0){
    blaster.play();
 var newShot = new BMissle(this.barrelx, this.barrely);
    bullets.push(newShot);
    BSClip -= 1;}
}

this.reload = function(){
  if (this.x === (width / 2) - scl && this.y === 0 && BSClip === 0)
  {
    BSClip = 10;
  }
}

this.Up = function(pos){
var d = dist(this.x, this.y, pos.x, pos.y);
    var barrelD = dist(this.barrelx, this.barrely, pos.x, pos.y);
    if (d < 50 || barrelD < 10) {
      return true;
    } else {
      return false;
    }
}



}
