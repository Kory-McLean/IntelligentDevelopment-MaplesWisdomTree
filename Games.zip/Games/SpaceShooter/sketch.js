var YS;
var BS;
var BSLife;
var YSLife ;
var BSClip;
var YSClip;
var bullets;
var music = new Audio("Halo Theme Song Original.mp3");
var explosion = new Audio("Explosion.mp3");
var ding = new Audio("DING.mp3");
music.loop = true;
var scl = 20;

function setup(){
  music.play();
  createCanvas(600, 800);
  YS = new YellowSpaceship();
  YSLife = 10;
  YSClip = 10;
  BS = new BlueSpaceship();
  BSLife = 10;
  BSClip = 10;
  bullets = [];
  placeLifeUp();
  window.confirm("Rules:\n1) You can only shoot 10 times without reloading\n2) To reload you must go back fully into your 'Starting Block'\n3) Collecting the Tokens Grants +1 Life\n4) Your Shield will disappear if you have less than 5 Health\n5) You an only stay in your boundary\n6) Blue used 'ASWD' amd 'G' to shoot\n7) Yellow uses the arrow keys and the '0' on the numpad to shoot");
  frameRate(10);
}
function draw(){
  background(51);
  if (YS.Up(t)) 
    {
      ding.play();
      YSLife += 1;
    placeLifeUp();}
  else if (BS.Up(t)){
    ding.play();
    BSLife += 1;
    placeLifeUp();
  }
  YMove();
  BMove();
  YS.show();
  YS.update();
  BS.show();
  BS.update();
  launch();
  buildBoard();
}

function launch(){
  for (var i = 0; i < bullets.length; i++) {
    bullets[i].update();
    bullets[i].show(); 
    bullets[i].hit();
  };
}
function BMove(){
if (keyIsDown(87)) {
    
    BS.dir(0, -20);
  } 
  else if (keyIsDown(83)) {
    BS.dir(0, 20);
  } 
  else if (keyIsDown(68)) {
    BS.dir(20, 0);
  } 
  else if (keyIsDown(65)) {
    BS.dir(-20, 0);
  }
}

function keyPressed() {
  if (keyCode === 71) {
    BS.shoot();
  } else if (keyCode === 96) {
    YS.shoot();
  }
}

function YMove() {

  if (keyIsDown(UP_ARROW)) {
    YS.dir(0, -20);
  } 
  else if (keyIsDown(DOWN_ARROW)) {
    YS.dir(0, 20);
  } 
  else if (keyIsDown(RIGHT_ARROW)) {
    YS.dir(20, 0);
  } 
  else if (keyIsDown(LEFT_ARROW)) {
    YS.dir(-20, 0);
  }
}

function buildBoard(){
  stroke(255)
  fill(255);
  rect(0, height/2 - 5, 600, 10 );
  rect((width / 2) - scl - 30, height-scl-45, 5 , 65 );
  rect((width / 2) +scl +  25, height-scl-45, 5 , 65 );
  rect((width / 2) - scl - 30 ,height-scl-50, 100,5);

  rect((width / 2) - scl - 30, 0, 5 , 65 );
  rect((width / 2) +scl +  25, 0, 5 , 65 );
  rect((width / 2) - scl - 30 ,65, 100,5);

  fill(0,255,0);
  rect(10, 10, 10 * BSLife ,10);
  rect(10, height - 20, 10 * YSLife ,10);

  if(BSLife <= 0)
  {
    explosion.play();
     if (window.confirm("Yellow Wins")){
      setup();
    }
  }
  else if(YSLife <= 0)
  {
    explosion.play();
    if ( window.confirm("Blue Wins"))
    {
      setup();
    }
  }
  fill(255,128,0);
  ellipse(t.x + 10, t.y + 10, 20, 20);
  fill(255,255,0);
  ellipse(t.x + 10, t.y + 10, 10, 10);
  fill(255,0,0);
  var Bx = 15;
  for (var i = 0; i < BSClip; i++) {
    ellipse(Bx, 30, 5, 5);
    Bx+=10;
  };
  var Yx = 15;
  for (var i = 0; i < YSClip; i++) {
    ellipse(Yx, height - 30, 5, 5);
    Yx+=10;
  };
} 

function placeLifeUp() {
  var cols = floor(width/scl);
  var rows = floor(height/scl);
  t = createVector(floor(random(cols)), floor(random(rows)));
  t.mult(scl);
}

