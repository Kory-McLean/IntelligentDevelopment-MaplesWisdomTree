var thud = new Audio("Thud.mp3");

function YMissle(x, y){
	this.x = x;
	this.y = y;
	this.speed = 5;


this.show = function(){
  stroke(51,255,51)
	fill(255, 0, 100);
	ellipse(this.x, this.y, 10, 10);
}

this.update = function(){
  if ( this.y <= 0)
  {
     this.x = 700;
    this.y  = height + 100;
    this.speed = 0;
  }
  else{
	this.y -= this.speed * 10;}
}
this.hit = function(){
  if ((BS.x - 20 <= this.x && this.x <= BS.x + 70) && (this.y <= BS.y + 50 && BS.y < this.y) )
  {
    thud.play();
    BSLife -= 1;
    this.x = 700;
    this.y  = height + 100;
    this.speed = 0;
  }
}
}




function BMissle(x, y){
  this.x = x;
  this.y = y;
  this.speed = 5;


this.show = function(){
  stroke(51,255,51)
  fill(255, 0, 100);
  ellipse(this.x, this.y, 10, 10);
}

this.update = function(){
  if ( this.y >= height)
  {
     this.x = 700;
    this.y  = height + 100;
    this.speed = 0;
  }
  else{
  this.y += this.speed * 10;}
}

this.hit = function(){
  if ((YS.x - 20 <= this.x && this.x <= YS.x + 70) && (YS.y + 20 >= this.y && YS.y - 40 <= this.y) )
  {
    thud.play();
    YSLife -= 1;
    this.x = 700;
    this.y  = -100;
    this.speed = 0;

  }
}
}

