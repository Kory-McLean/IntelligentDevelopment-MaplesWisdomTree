var Red;

function setup(){
  createCanvas(1800, 700);
  Red = new Red();
  placeLifeUp();
  frameRate(10);
  push();
}


function draw(){
  background(51);
  if (t.y < height - 20){t.y += 20;}
  fill(255,128,0);
  ellipse(t.x + 10, t.y + 10, 20, 20);
  fill(255,255,0);
  ellipse(t.x + 10, t.y + 10, 10, 10);
  Red.update();
  Red.showStand(1);
  if ( Red.Up(t)){
    RLife += 1;
    placeLifeUp();
  }
}

function placeLifeUp() {
  var cols = floor(width/20);
  t = createVector(floor(random(cols)), -60);
  t.mult(20);
}


