var thud = new Audio("Thud.mp3");

function RMissle(x, y){
  this.x = x;
  this.y = y;
  target = Blue.x;
  if (target > x){
    this.speed = 5;
  }
  else{this.speed = -5}


this.show = function(){
  stroke(51,255,51)
  fill(255, 255, 0);
  ellipse(this.x, this.y, 10, 10);
}

this.update = function(){
  if ( this.x >= width)
  {
     this.x = -500;
    this.y  = height + 100;
    this.speed = 0;
  }
  else{
  this.x += this.speed * 10;}
}
}

