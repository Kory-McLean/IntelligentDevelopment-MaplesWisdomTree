var Red;
var Blue;
var RClip;
var RLife;
var BLife;
var BClip;
var RedStance;
var BlueStance;
var RJump;
var BJump;
var bullets;
var RStanceType;
var BStanceType;
var Rscore = 0;
var Bscore = 0;
var music = new Audio("The Halo 3 Warthog Run- The Complete Extended Version.mp3");
music.loop = true;


function setup(){
  music.play();
  createCanvas(1800, 700);
  Red = new Red();
  Blue = new Blue();
  RedStance = 1;
  RStanceType = 1;
  BlueStance = 1;
  BStanceType = 1;
  push();
  RClip = 10;
  BClip = 10;
  placeLifeUp();
  RLife = 10;
  BLife = 10;
  bullets = [];
  RJump = false;
  BJump = false;
  frameRate(10);
  push();
}

function launch(){
  for (var i = 0; i < bullets.length; i++) {
    bullets[i].update();
    bullets[i].show(); 
    bullets[i].hit();
  };
}

function draw(){
  background(51);
  buildBoard();
  if (t.y < height - 20){t.y += 20;}
  fill(255,128,0);
  ellipse(t.x + 10, t.y + 10, 20, 20);
  fill(255,255,0);
  ellipse(t.x + 10, t.y + 10, 10, 10);
  RMove();
  BMove();
  Red.update();
  Blue.update();
  launch();
  if (RedStance === 1) {
    Red.showStand(RStanceType);}
  else{
  Red.showDown(RStanceType);}
  if (BlueStance === 1) {
    Blue.showStand(BStanceType);}
  else{
  Blue.showDown(BStanceType);}
  if (Blue.Up(t)){
    BLife += 1;
    placeLifeUp();
  }
  else if ( Red.Up(t)){
    RLife += 1;
    placeLifeUp();
  }
}

function keyPressed(){
  if (keyCode === 87){
  RJump = true;
  }
  else if (keyCode === UP_ARROW){
    BJump = true;
  }
  else if (keyCode === 71) {
    Red.shoot(RStanceType);
  } else if (keyCode === 96) {
    Blue.shoot();
  }
  else if (keyCode === 82){
    Red.reloadClip();
  }
  else if (keyCode === 98){
    Blue.reloadClip();
  }
}

function RMove() {

if (keyIsDown(83)) {
    RedStance = 0;
  }
  else if (!keyIsDown(83)){
    RedStance  = 1;
  }
  if (keyIsDown(68)) {
    Red.dir(20, 0);
  } 
  else if (keyIsDown(65)) {
    Red.dir(-20, 0);
  }
}

function BMove() {

if (keyIsDown(DOWN_ARROW)) {
    BlueStance = 0;
  }
  else if (!keyIsDown(DOWN_ARROW)){
    BlueStance  = 1;
  }
  if (keyIsDown(RIGHT_ARROW)) {
    Blue.dir(20, 0);
  } 
  else if (keyIsDown(LEFT_ARROW)) {
    Blue.dir(-20, 0);
  }
}


function buildBoard(){
  stroke(255);
  var scl = 20;
  fill(0,255,0);
  strokeWeight(5);
  stroke(255 ,0, 0);
  rect(10, 10, 10 * RLife ,10);
  stroke(51,51,255);
  rect(width  -10 - 10 * BLife, 10, 10 * BLife ,10);
  stroke(255);
  strokeWeight(1);
  fill (255);
  rect ((width - 5) / 2, 0, 10, 50);
  var Rx = 25
  var Bx = 25
  for (var i = 0; i < Rscore; i++) {
    ellipse((width - 5)/2 - Rx ,20, 20, 20);
    Rx += 25;
  };
  for (var i = 0; i < Bscore; i++) {
    ellipse((width - 5)/2 +10 +  Bx ,20, 20, 20);
    Bx += 25;
  };
  fill(255,0,0);
  var Rx = 15;
  for (var i = 0; i < RClip; i++) {
    ellipse(Rx, 30, 5, 5);
    Rx+=10;
  };
  var Bx = width  -15;
  for (var i = 0; i < BClip; i++) {
    ellipse(Bx, 30, 5, 5);
    Bx-=10;
  };
if(BLife <= 0)
  {
    window.alert("Point to Red");
    Rscore += 1;
    ResetGame();
    pop();
  }
  else if(RLife <= 0)
  {
    if ( window.confirm("Blue point"))
    {
      Bscore += 1;
      ResetGame();
      pop();
    }
  }
}

function ResetGame(){
      RClip = 10;
      BClip = 10;
      RLife = 10;
      BLife = 10;
      bullets = [];
      Red.x = width/4;
      Red.y = height - 120;
      Blue.x = 3* width / 4;
      Blue.y = height - 120;
} 

function placeLifeUp() {
  var cols = floor(width/20);
  t = createVector(floor(random(cols)), -60);
  t.mult(20);
}


