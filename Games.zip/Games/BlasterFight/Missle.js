var thud = new Audio("Thud.mp3");

function BMissle(x, y){
	this.x = x;
	this.y = y;
  target = Red.x;
  if (target > x){
    this.speed = 5;
  }
  else{this.speed = -5}


this.show = function(){
  stroke(51,255,51)
	fill(102,255,255);
	ellipse(this.x, this.y, 10, 10);
}

this.update = function(){
  if ( this.x <= 0)
  {
     this.x = -500;
    this.y  = height + 100;
    this.speed = 0;
  }
  else{
	this.x += this.speed * 10;}
}
this.hit = function(){
  if (RedStance === 1)
    {if ((Red.x <= this.x && this.x <= Red.x + 70) && (this.y >= Red.y && Red.y + 120 >= this.y) )
      {
        RLife -= 1;
        this.x = -500;
        this.y  = height + 100;
        this.speed = 0;
      }
    }
  else{
        if ((Red.x <= this.x && this.x <= Red.x + 70) && (this.y >= Red.y + 45  && Red.y + 120 >= this.y) )
        {
          RLife -= 1;
          this.x = -500;
          this.y  = height + 100;
          this.speed = 0;
        }
    }
  }
}




function RMissle(x, y){
  this.x = x;
  this.y = y;
  target = Blue.x;
  if (target > x){
    this.speed = 5;
  }
  else{this.speed = -5}


this.show = function(){
  stroke(51,255,51)
  fill(255, 255, 0);
  ellipse(this.x, this.y, 10, 10);
}

this.update = function(){
  if ( this.x >= width)
  {
     this.x = -500;
    this.y  = height + 100;
    this.speed = 0;
  }
  else{
  this.x += this.speed * 10;}
}

this.hit = function(){
  if (BlueStance === 1)
    {if ((Blue.x <= this.x && this.x <= Blue.x + 70) && (this.y >= Blue.y && Blue.y + 120 >= this.y) )
    {
      BLife -= 1;
      this.x = -500;
      this.y  = height + 100;
      this.speed = 0;
    }
    }
  else{
    if ((Blue.x <= this.x && this.x <= Blue.x + 70) && (this.y >= Blue.y + 45 && Blue.y + 120 >= this.y) )
    {
      BLife -= 1;
      this.x = -500;
      this.y  = height + 100;
      this.speed = 0;
    }
  }
}
}

