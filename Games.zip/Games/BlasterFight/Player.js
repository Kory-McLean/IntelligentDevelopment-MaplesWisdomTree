function Red(){
	this.x = width/4;
	this.y = height - 120;
	this.yspeed = 20;
	this.jumpCount = 6;
	this.barrelx = this.x + 80;
	this.barrely = this.y + 35;

	
this.showStand = function(type){
	if (type === 1){
	this.barrelx = this.x + 80;
	this.barrely = this.y + 35;
	stroke(0);
	fill(255, 0, 0);
	//head
	rect(this.x, this.y,40, 30);
	fill(206, 245, 249);
	strokeWeight(3);
	rect(this.x + 20, this.y + 5, 20, 10);
	strokeWeight(1);
	//arm
	fill(255, 0, 0);
	rect(this.x, this.y + 30, 80, 10);
	fill(255, 128, 0);
	rect(this.x + 55, this.y + 27.5, 25, 15);
	//body
	fill(255, 0, 0);
	rect(this.x, this.y + 40, 45, 40);
	//legs
	rect(this.x, this.y + 80, 15, 30 );
	rect(this.x + 30, this.y + 80, 15, 30 );
	//feet
	fill(0);
	rect(this.x, this.y + 110, 25, 10);
	rect(this.x + 30, this.y + 110, 25, 10);
	//jetpack
	stroke(160,160,160);
	fill(160, 160,160);
	ellipse(this.x - 10, this.y + 25, 20, 10);
	rect(this.x - 21, this.y + 25, 20, 40);}
	else {
	this.barrelx = this.x - 40;
	this.barrely = this.y + 35;;
	stroke(0);
	fill(255, 0, 0);
	//head
	rect(this.x, this.y,40, 30);
	fill(206, 245, 249);
	strokeWeight(3);
	rect(this.x, this.y + 5, 20, 10);
	strokeWeight(1);
	//arm
	fill(255, 0, 0);
	rect(this.x - 40, this.y + 30, 80, 10);
	fill(255, 128, 0);
	rect(this.x - 40, this.y + 27.5, 25, 15);
	//body
	fill(255, 0, 0);
	rect(this.x - 5, this.y + 40, 45, 40);
	//legs
	rect(this.x - 5, this.y + 80, 15, 30 );
	rect(this.x + 25, this.y + 80, 15, 30 );
	//feet
	fill(0);
	rect(this.x - 15, this.y + 110, 25, 10);
	rect(this.x + 15, this.y + 110, 25, 10);
	//jetpack
	stroke(160,160,160);
	fill(160, 160,160);
	ellipse(this.x + 51, this.y + 25, 20, 10);
	rect(this.x + 41, this.y + 25, 20, 40);
	};
}

this.shoot = function(){
 if (RClip > 0){
 var newShot = new RMissle(this.barrelx, this.barrely);
    bullets.push(newShot);
    RClip -= 1;}
}

this.dir = function(x, y) {
this.x += x;
this.y += y;
}

this.showDown = function(type){
	if (type === 1){
	stroke(0);
	fill(255, 0, 0);
	//head
	rect(this.x, this.y + 45, 40, 30);
	fill(206, 245, 249);
	strokeWeight(3);
	rect(this.x + 20, this.y + 50, 20, 10);
	strokeWeight(1);
	//arm
	fill(255, 0, 0);
	rect(this.x, this.y + 65, 80, 10);
	fill(255, 128, 0);
	rect(this.x + 55, this.y + 62.5, 25, 15);
	//body
	fill(255, 0, 0);
	rect(this.x, this.y + 75, 45, 20);
	//jetpack
	stroke(160,160,160);
	fill(160, 160,160);
	ellipse(this.x - 10, this.y + 60, 20, 10);
	rect(this.x - 21, this.y + 60, 20, 40);
	//legs
	stroke(0);
	fill(255, 0, 0);
	rect(this.x + 40, this.y + 95, 15, 15 );
	rect(this.x - 20, this.y + 95, 35, 15 );
	//feet
	fill(0);
	rect(this.x - 20, this.y + 95, 10, 25);
	rect(this.x + 40, this.y + 110, 25, 10);}
	else {
	stroke(0);
	fill(255, 0, 0);
	//head
	rect(this.x, this.y + 45, 40, 30);
	fill(206, 245, 249);
	strokeWeight(3);
	rect(this.x, this.y + 50, 20, 10);
	strokeWeight(1);
	//arm
	fill(255, 0, 0);
	rect(this.x - 40, this.y + 65, 80, 10);
	fill(255, 128, 0);
	rect(this.x - 40, this.y + 62.5, 25, 15);
	//body
	fill(255, 0, 0);
	rect(this.x - 5, this.y + 75, 45, 20);
	//jetpack
	stroke(160,160,160);
	fill(160, 160,160);
	ellipse(this.x + 52, this.y + 60, 20, 10);
	rect(this.x + 41, this.y + 60, 20, 40);
	//legs
	stroke(0);
	fill(255, 0, 0); 
	rect(this.x - 20, this.y + 95, 15, 15 );
	rect(this.x + 20, this.y + 95, 35, 15 );
	//feet
	fill(0);
	rect(this.x + 50, this.y + 95, 10, 25);
	rect(this.x - 30, this.y + 110, 25, 10);
	};
}

this.update = function(){
	if (RJump && this.jumpCount > 0 ){
		this.y -= this.yspeed;
		this.jumpCount -= 1;
		if (BStanceType === 1){
			produceLeftFlame(this);
		}
		else{produceRightFlame(this);}
	}
	else{
		RJump = false;
		this.jumpCount = 6;
		if (this.y != height - 120){
			this.y += this.yspeed;
		}
	}
	if (RedStance === 1){
	this.barrelx = this.x + 80;
	this.barrely = this.y + 35;}
	else {this.barrelx = this.x + 80;
		this.barrely = this.y + 70;}
	if (Blue.x < this.x){
		RStanceType = 0;

	}
	else {RStanceType = 1;}
	this.x = constrain(this.x, 20, width - 60);
	this.y = constrain(this.y, 0, height);
}

this.reloadClip = function(){
	if (RClip === 0){
		RClip = 10;
	}
}

this.Up = function(pos){
    return (this.x + 60 >= pos.x && this.x <= pos.x) && (this.y <= pos.y && this.y + 130 >= pos.y);
}
}




function Blue(){
	this.x =  3 * width / 4;
	this.y = height - 120;
	this.yspeed = 20;
	this.jumpCount = 6;
	this.barrelx = this.x - 40;
	this.barrely = this.y + 35;

this.showStand = function(type){
	if (type === 1) {
		this.barrelx = this.x - 40;
	this.barrely = this.y + 35;
		stroke(0);
	fill(51,51,255);
	//head
	rect(this.x, this.y,40, 30);
	fill(206, 245, 249);
	strokeWeight(3);
	rect(this.x, this.y + 5, 20, 10);
	strokeWeight(1);
	//arm
	fill(51,51,255);
	rect(this.x - 40, this.y + 30, 80, 10);
	fill(255, 128, 0);
	rect(this.x - 40, this.y + 27.5, 25, 15);
	//body
	fill(51,51,255);
	rect(this.x - 5, this.y + 40, 45, 40);
	//legs
	rect(this.x - 5, this.y + 80, 15, 30 );
	rect(this.x + 25, this.y + 80, 15, 30 );
	//feet
	fill(0);
	rect(this.x - 15, this.y + 110, 25, 10);
	rect(this.x + 15, this.y + 110, 25, 10);
	//jetpack
	stroke(160,160,160);
	fill(160, 160,160);
	ellipse(this.x + 51, this.y + 25, 20, 10);
	rect(this.x + 41, this.y + 25, 20, 40);}
	else{
		this.barrelx = this.x + 80;
	this.barrely = this.y + 35;
		stroke(0);
	fill(51,51,255);
	//head
	rect(this.x, this.y,40, 30);
	fill(206, 245, 249);
	strokeWeight(3);
	rect(this.x + 20, this.y + 5, 20, 10);
	strokeWeight(1);
	//arm
	fill(51,51,255);
	rect(this.x, this.y + 30, 80, 10);
	fill(255, 128, 0);
	rect(this.x + 55, this.y + 27.5, 25, 15);
	//body
	fill(51,51,255);
	rect(this.x, this.y + 40, 45, 40);
	//legs
	rect(this.x, this.y + 80, 15, 30 );
	rect(this.x + 30, this.y + 80, 15, 30 );
	//feet
	fill(0);
	rect(this.x, this.y + 110, 25, 10);
	rect(this.x + 30, this.y + 110, 25, 10);
	//jetpack
	stroke(160,160,160);
	fill(160, 160,160);
	ellipse(this.x - 10, this.y + 25, 20, 10);
	rect(this.x - 21, this.y + 25, 20, 40);}
}

this.dir = function(x, y) {
this.x += x;
this.y += y;
}

this.showDown = function(type){
	if (type === 1) {
			this.barrelx = this.x - 40;
	this.barrely = this.y + 70;
	stroke(0);
	fill(51,51,255);
	//head
	rect(this.x, this.y + 45, 40, 30);
	fill(206, 245, 249);
	strokeWeight(3);
	rect(this.x, this.y + 50, 20, 10);
	strokeWeight(1);
	//arm
	fill(51,51,255);
	rect(this.x - 40, this.y + 65, 80, 10);
	fill(255, 128, 0);
	rect(this.x - 40, this.y + 62.5, 25, 15);
	//body
	fill(51,51,255);
	rect(this.x - 5, this.y + 75, 45, 20);
	//jetpack
	stroke(160,160,160);
	fill(160, 160,160);
	ellipse(this.x + 52, this.y + 60, 20, 10);
	rect(this.x + 41, this.y + 60, 20, 40);
	//legs
	stroke(0);
	fill(51,51,255); 
	rect(this.x - 20, this.y + 95, 15, 15 );
	rect(this.x + 20, this.y + 95, 35, 15 );
	//feet
	fill(0);
	rect(this.x + 50, this.y + 95, 10, 25);
	rect(this.x - 30, this.y + 110, 25, 10);}
	else {
		this.barrelx = this.x + 80;
	this.barrely = this.y + 70;
		stroke(0);
	fill(51,51,255);
	//head
	rect(this.x, this.y + 45, 40, 30);
	fill(206, 245, 249);
	strokeWeight(3);
	rect(this.x + 20, this.y + 50, 20, 10);
	strokeWeight(1);
	//arm
	fill(51,51,255);
	rect(this.x, this.y + 65, 80, 10);
	fill(255, 128, 0);
	rect(this.x + 55, this.y + 62.5, 25, 15);
	//body
	fill(51,51,255);
	rect(this.x, this.y + 75, 45, 20);
	//jetpack
	stroke(160,160,160);
	fill(160, 160,160);
	ellipse(this.x - 10, this.y + 60, 20, 10);
	rect(this.x - 21, this.y + 60, 20, 40);
	//legs
	stroke(0);
	fill(51,51,255);
	rect(this.x + 40, this.y + 95, 15, 15 );
	rect(this.x - 20, this.y + 95, 35, 15 );
	//feet
	fill(0);
	rect(this.x - 20, this.y + 95, 10, 25);
	rect(this.x + 40, this.y + 110, 25, 10);
	}
}

this.shoot = function(){
 if (BClip > 0){
 var newShot = new BMissle(this.barrelx, this.barrely);
    bullets.push(newShot);
    BClip -= 1;}
}

this.update = function(){
	if (BJump && this.jumpCount > 0 ){
		this.y -= this.yspeed;
		this.jumpCount -= 1;
		if (BStanceType === 1){
			produceRightFlame(this);
		}
		else{produceLeftFlame(this);}
	}
		
	else{
		BJump = false;
		this.jumpCount = 6;
		if (this.y != height - 120){
			this.y += this.yspeed;
		}
	}
	if (BlueStance === 1){
	this.barrelx = this.x - 40;
	this.barrely = this.y + 35;}
	else {this.barrelx = this.x - 40;
		this.barrely = this.y + 70;}
	if (Red.x > this.x){
		BStanceType = 0;

	}
	else {BStanceType = 1;}
	this.x = constrain(this.x, 20, width - 60);
	this.y = constrain(this.y, 0, height);
}

this.reloadClip = function(){
	if (BClip === 0){
		BClip = 10;
	}
}

this.Up = function(pos){
return (this.x + 60 >= pos.x && this.x <= pos.x) && (this.y <= pos.y && this.y + 130 >= pos.y);
}
} 

function produceLeftFlame(Player){
		noStroke();
  		fill(102, 102, 255);
  		rect(Player.x - 20, Player.y + 60, 20 ,15);
  		fill(102, 178, 255);
  		rect(Player.x - 17.5, Player.y + 75, 15 ,10);
  		fill(102, 255, 255);
  		rect(Player.x - 15, Player.y + 85, 10 ,5);
}

function produceRightFlame(Player){
		noStroke();
  		fill(102, 102, 255);
  		rect(Player.x + 42, Player.y + 60, 20 ,15);
  		fill(102, 178, 255);
  		rect(Player.x + 44.5, Player.y + 75, 15 ,10);
  		fill(102, 255, 255);
  		rect(Player.x +47, Player.y + 85, 10 ,5);
	}