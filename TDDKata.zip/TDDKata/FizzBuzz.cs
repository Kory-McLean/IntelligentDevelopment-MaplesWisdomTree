﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TDDKata1
{
    public class FizzBuzz
    {
        List<string> _VariationStrings;
        List<int> _VariationMultiples;

        public FizzBuzz(List<string>VariationStrings=null, List<int> VariationMultiples=null)
        {
            _VariationStrings = VariationStrings;
            _VariationMultiples = VariationMultiples;
        }

        public string Play(string number)
        {
            string result = "";
            for (int index = 0; index < _VariationStrings.Count; index++)
            {
                result += CheckMultipleofN(number, _VariationMultiples[index], _VariationStrings[index]);
            }
            return result == "" ? number : result.Trim();
        }

        public string CheckMultipleofN(string argument, int N, string result)
        {
            return int.Parse(argument) % N == 0 ? String.Format("{0} ",result) : null;
        }

        internal void Start()
        {
            Console.WriteLine("Welcome to Fizz Buzz Enter 'end' after a round to exit. \n Press Enter to Begin.");
            Console.ReadLine();
            Console.WriteLine("Please Enter your String Values, Enter stop when you are finished:");
            List<string> Strings = new List<string> { };
            do
            {
                Console.WriteLine("Enter String:");
                Strings.Add(Console.ReadLine());
                Console.WriteLine("Press enter to continue or stop to move on.");
            } while (Console.ReadLine() != "stop");
            Console.WriteLine("Please Enter your Multiple Values in the same order to the corresponding strings, Enter stop when you are finished:");
            List<int> Multiples = new List<int> { };
            do
            {
                Console.WriteLine("Enter Multiple:");
                Multiples.Add(int.Parse(Console.ReadLine()));
                Console.WriteLine("Press enter to continue or stop to move on.");

            } while (Console.ReadLine() != "stop");
            Console.Clear();
            FizzBuzz Game = new FizzBuzz(Strings, Multiples);
            Console.WriteLine("Let us Begin!");
            do
            {
                Console.WriteLine("Please enter your number:");
                string n = Console.ReadLine();
                Console.WriteLine(Game.Play(n));
                Console.WriteLine("Press Enter to Continue or End to Exit");
            } while (Console.ReadLine().ToLower() != "end");
        }
    }
}
