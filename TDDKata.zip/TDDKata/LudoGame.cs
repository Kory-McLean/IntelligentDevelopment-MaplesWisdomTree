﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TDDKata1
{
    public class LudoGame
    {
        public List<Player> Players = new List<Player> { };
        public List<List<Player>> Board= new List<List<Player>> {};
        public List<List<Peg>> FinishSquare = new List<List<Peg>> { };



        public void FillBoard()
        {
            int x = 0;
            for (int i = 0; i < 57; i++)
            {
                if (i % 4 == 0)
                {
                    Board.Add(new List<Player> { Players[0] });
                    x += 1;
                } else { Board.Add(new List<Player> { }); }
            }
        }

        public LudoGame(int PlayersAmount)
        {
            List<string> Colours = new List<string> { "Red", "Blue", "Yellow", "Green" };
            for (int i = 0; i < PlayersAmount; i++)
            {
                Players.Add(new Player(Colours[i]));
            }
            FillBoard();
        }

        public bool CheckCollisions()
        {
            foreach (var spot in Board)
            {
                if (spot.Count >= 2)
                {
                    return false;
                }
            }
            return true;
        }

        public string CheckWinner()
        {
            foreach (var player in Players)
            {
                foreach (Peg item in player.Pegs)
                {
                    if (item.Location != 56)
                    {
                        return "";
                    }
                }
                return String.Format("The winner is {0}", player);
            }
            return "";
        }
    }
}
