﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TDDKata1
{
    public class SnakesAndLadders
    {
        public List<Token> Tokens = new List<Token> { };
        public List<int> rolled = new List<int> { };
        public Random Dice = new Random();
        public List<List<int>> Snakes = new List<List<int>> { new List<int> { 12, 2 }, new List<int> { 7, 3 }, new List<int> { 59, 32 }, new List<int> { 88, 64 }, new List<int> { 97, 25 }, new List<int> { 22, 10 } };
        public List<List<int>> Ladders = new List<List<int>> { new List<int> { 3, 13 }, new List<int> { 14, 24 }, new List<int> { 30, 49 }, new List<int> { 61, 65 } , new List<int> { 73, 99 }, new List<int> { 57, 59 } };

        public SnakesAndLadders(int AmountPlayer=0)
        {
            for (int i = 0; i < AmountPlayer; i++)
            {
                Token potential = new Token((i + 1).ToString());
                CheckStartingPostion(potential);
            }
            Tokens.OrderBy(t => t.StartingRoll).ToList();
        }

        public void Start()
        {
            int cur = 0;
            while (DeclareWinner() == "")
            {
                Console.Clear();
                Console.WriteLine(String.Format("Player {0} Press Enter to Roll", Tokens[cur].ID));
                Console.ReadLine();
                Console.Clear();
                Console.WriteLine("At the end of Player " + Tokens[cur].ID.ToString() + "'s Turn:");
                int roll = Roll();
                int source = Tokens[cur].location;
                PlaceToken(Tokens[cur], roll);
                if (Tokens[cur].location - source > 6)
                {
                    Console.WriteLine("Ladder Hit!");
                }
                else if (Tokens[cur].location < source + roll)
                {
                    Console.WriteLine("Snake Hit!");
                }
                else if (Tokens[cur].location > 100)
                {
                    Tokens[cur].location = source;
                    Console.WriteLine("OverShot!");
                }
                Console.WriteLine("You Rolled a " + roll.ToString());
                Console.WriteLine(PrintBoard());
                Console.ReadLine();
                if (cur + 1 == Tokens.Count)

                {
                    cur = 0;
                }
                else
                {
                    cur += 1;
                }

            }
            Console.WriteLine("The winner is Player " + DeclareWinner());
            Console.ReadLine();
        }

        public string PrintBoard()
        {
            string result = "";
            foreach (var item in Tokens)
            {
                result += String.Format("Player {0}\nLocation = {1}\n\n", item.ID, item.location);
            }
            return result;
        }

        private void CheckStartingPostion(Token potential)
        {
            while (rolled.Contains(potential.StartingRoll))
            {
                potential.StartingRoll = Roll();
            }
            Tokens.Add(potential);
        }

        public void PlaceToken(Token token, int distance)
        {
            int start = token.location;
            CheckForSnake(token, distance);
            CheckForLadder(token, distance);
           if (token.location == start)
            {
                token.location += distance;
            }
        }

        public void CheckForSnake(Token token, int distance)
        {
            foreach (var snake in Snakes)
            {
                if (token.location + distance == snake[0])
                {
                    token.location = snake[1];
                }
            }
        }

        public void CheckForLadder(Token token, int distance)
        {
            foreach (var ladder in Ladders)
            {
                if (token.location + distance == ladder[0])
                {
                    token.location = ladder[1];
                }
            }
        }

        public int Roll()
        {
            return Dice.Next(1, 7);
        }

        public string DeclareWinner()
        {
            foreach (var player in Tokens)
            {
                if (player.location == 100)
                {
                    return player.ID;
                }
            }
            return "";
        }
    }
    public class Token
    {
        public int location;
        public string ID;
        public int StartingRoll;
        public Token(string id)
        {
            location = 1;
            ID = id;
            Random Dice = new Random();
            StartingRoll = Dice.Next(1, 7);
        }
    }
}
