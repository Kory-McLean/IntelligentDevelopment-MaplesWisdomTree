﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TDDKata
{
    public class StringCalculator
    {
        public StringCalculator()
        {
        }

        public int Add(string numbers)
        {
            CheckForExceptions(RemoveDelimiter(numbers));
            return numbers == "" ? 0 : CalculateSum("", 0, RemoveDelimiter(numbers));
        }

        private static int CalculateSum(string curNumber, int result, string trimmed)
        {
            for (int index = 0; index < trimmed.Length; index++)
            {
                if (isNumber(trimmed, index))
                    curNumber += trimmed[index].ToString();
                else if (int.TryParse(curNumber, out int number))
                { int curInt = int.Parse(curNumber);
                    result += curInt <= 1000? curInt: 0;
                    curNumber = "";}
            }
            return result += int.Parse(curNumber) <= 1000 ? int.Parse(curNumber) : 0;
        }

        private void CheckForExceptions(string trimmed)
        {
            if (trimmed.Contains('-'))
                throw new ArgumentOutOfRangeException(String.Format("Negatives not allowed: {0}", ExtractNegatives(trimmed)));
        }

        private static string RemoveDelimiter(string numbers)
        {
            if (numbers.Contains("//"))
                return numbers.Substring(numbers.IndexOf('\n') + 1);
            else { return numbers;}
        }

        private static bool isNumber(string numbers, int index)
        {
            return int.TryParse(numbers[index].ToString(), out int number);
        }

        public string ExtractNegatives(string numbers)
        {
            string result = "";
            for (int i = 0; i < numbers.Length; i++)
            {
                if (numbers[i] == '-')
                {
                    result += numbers[i];
                        i += 1;
                    while (i < numbers.Length && isNumber(numbers, i))
                    {
                        result += numbers[i];
                        i += 1;
                    }
                    result += ", " ;
                }
            }
            return result.Substring(0 , result.Length - 2);
        }
    }
}
