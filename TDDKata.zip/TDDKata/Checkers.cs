﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TDDKata1
{
    public class Checkers
    {
        public List<List<Spot>> Board;
        public Checkers()
        {
            Board = new List<List<Spot>> { };
            FillBoard();
            PlacePlayers();
        }
        public string DeclareWinner()
        {
            var winner = "";
            foreach (var row in Board)
            {
                foreach (var spot in row)
                {
                    if (spot.Occupants.Count != 0)
                    {
                        var poten = spot.Occupants[0].ID;
                        if (winner == "")
                        {
                            winner = poten;
                        }
                        if (winner != "" && poten != winner)
                        {
                            return "";
                        }
                    }
                }
            }
            return winner;
        }
        public void KingAll()
        {
            foreach (var spot in Board[0])
            {
                if (spot.Occupants.Count != 0)
                {
                    if (spot.Occupants[0].ID != "KWhite" && spot.Occupants[0].ID != "Black")
                    {
                        spot.Occupants[0].KingMe();
                    }
                }
            }
            foreach (var spot in Board[7])
            {
                if (spot.Occupants.Count != 0)
                {
                    if (spot.Occupants[0].ID != "KBlack" && spot.Occupants[0].ID != "White")
                    {
                        spot.Occupants[0].KingMe();
                    }
                }
            }
        }

        public void FillBoard()
        {
            for (int i = 0; i < 8; i++)
            {
               List<Spot> Row = new List<Spot> { };
                for (int spot = 0; spot < 8; spot++)
                {
                    Row.Add(new Spot());
                }
                Board.Add(Row);
            }
        }
        public void PlaceEvenRow(List<Spot> Row, string Player)
        {
            for (int i = 0; i < Row.Count(); i++)
            {
                if (i % 2 == 0)
                {
                    Row[i].Occupants.Add(new Disc(Player));
                }
            }
        }
        public void PlaceOddRow(List<Spot> Row, string Player)
        {
            for (int i = 0; i < Row.Count(); i++)
            {
                if (i % 2 != 0)
                {
                    Row[i].Occupants.Add(new Disc(Player));
                }
            }
        }
        public void PlacePlayers()
        {
            PlaceOddRow(Board[0], "Black");
            PlaceEvenRow(Board[1], "Black");
            PlaceOddRow(Board[2], "Black");

            PlaceEvenRow(Board[5], "White");
            PlaceOddRow(Board[6], "White");
            PlaceEvenRow(Board[7], "White");
        }

        public string PrintBoard()
        {
            string Result = "Board:\n\nX|1--2--3--4--5--6--7--8\n________________________\n";
            string Rows = "ABCDEFGH";
            int curRow = 0;
            foreach (var Row in Board)
            {
                string rowstring = String.Format("{0}|", Rows[curRow]);
                foreach (var spot in Row)
                {
                    if (spot.Occupants.Count() == 0)
                    {
                        if (Row.IndexOf(spot) % 2 != 0 && curRow % 2 == 0)
                        {
                            rowstring += "#--";
                        }
                        else if (Row.IndexOf(spot) % 2 == 0 && curRow % 2 != 0)
                        {
                            rowstring += "#--";
                        }
                        else { rowstring += "*--"; }
                    }
                    else if (spot.Occupants[0].ID == "White")
                    {
                        rowstring += "W--";
                    }
                    else if (spot.Occupants[0].ID == "KWhite")
                    {
                        rowstring += "KW-";
                    }
                    else if (spot.Occupants[0].ID == "KBlack")
                    {
                        rowstring += "KB-";
                    }
                    else
                    {
                        rowstring += "B--";
                    }
                }
                Result += rowstring.Substring(0,rowstring.Length-2) + "\n";
                curRow += 1;
            }
            return Result;

        }

        internal void Start()
        {
            Console.WriteLine("Welcome to Checkers!(queue music, *Boom Bang* go the fireworks)\nEnter 'quit' to exit or press enter to contiue\n\n" + PrintBoard());
  
            var cur = "Black";
            var opp = "White";
            while (Console.ReadLine().ToLower() != "quit" && DeclareWinner() == "")
            {
                Console.Clear();
                Console.WriteLine(PrintBoard());
                List<Spot> path = CreatePath(cur);
                while (!path[0].ValidPathPatternPerTeam(path, cur))
                {
                    Console.WriteLine("Please Enter a Valid path");
                    path = CreatePath(cur);
                }
                path[0].Jump(path);
                KingAll();
                var next = cur;
                cur = opp;
                opp = next;
            }
            if (DeclareWinner() != "")
            {
                Console.WriteLine("The Winner is " + DeclareWinner());
            }
            
        }

        private List<Spot> CreatePath(string cur)
        {

            Console.WriteLine(cur + " Please enter which disc you wanna move");
            string disc = Console.ReadLine();
            while (Translatetospot(disc).Occupants.Count == 0 || !Translatetospot(disc).Occupants[0].ID.Contains(cur)) 
            {
                Console.WriteLine("You cannot move this one");
                Console.WriteLine(cur + " Please enter which disc you wanna move");
                disc = Console.ReadLine();
            }
            Console.WriteLine("Please enter it's Path, enter stop to finish");
            List<Spot> path = new List<Spot> { Translatetospot(disc)};
            string spot = Console.ReadLine();
            string curdisc = disc;
            do
            {
                
                while (!ValidMove(curdisc, spot, Translatetospot(disc).Occupants[0].ID))
                {
                    Console.WriteLine(String.Format("Please Enter a Valid Move: {0}->{1} is Invalid", curdisc, spot));
                    spot = Console.ReadLine();
                }
                curdisc = spot;
                path.Add(Translatetospot(spot));
                Console.WriteLine(String.Format("Current Position: {0}", curdisc));
                Console.WriteLine("Enter a Position then Press enter to Add or stop to finish.");
                spot = Console.ReadLine();
            } while (spot.ToLower() != "stop");
            return path;
        }

        public Spot Translatetospot(string s)
        {
            var row = "ABCDEFGH".IndexOf(s[0]);
            return Board[row][int.Parse(s[1].ToString()) - 1];
        }

        public bool ValidMove(string source, string destination, string id)
        {
            Spot Testee = new Spot();
            Testee.Occupants.Add(new Disc(id));
            if (Testee.Occupants[0].ID.Contains('K'))
            {
                return KingCanMove(source, destination);
            }
            else if (Testee.Occupants[0].ID == "Black")
            {
                return BlackCanMove(source, destination);
            }
            else
            {
                return WhiteCanMove(source, destination);
            }
        }

        private static bool KingCanMove(string source, string destination)
        {
            return int.Parse(source[1].ToString()) + 1 == int.Parse(destination[1].ToString()) || int.Parse(source[1].ToString()) - 1 == int.Parse(destination[1].ToString());
        }

        public bool WhiteCanMove(string source, string destination)
        {
            string coloumns = "ABCDEFGH";
            return (int.Parse(source[1].ToString()) + 1 == int.Parse(destination[1].ToString()) ||
                int.Parse(source[1].ToString()) - 1 == int.Parse(destination[1].ToString())) &&
                                (coloumns.IndexOf(source[0]) == 1 + coloumns.IndexOf(destination[0]));
        }

        public bool BlackCanMove(string source, string destination)
        {
            string coloumns = "ABCDEFGH";
            return (int.Parse(source[1].ToString()) + 1 == int.Parse(destination[1].ToString()) || 
                int.Parse(source[1].ToString()) - 1 == int.Parse(destination[1].ToString())) &&
                                (coloumns.IndexOf(source[0]) == coloumns.IndexOf(destination[0]) - 1);
        }

        public class Spot
        {
            public List<Disc> Occupants = new List<Disc> { };
            public Spot()
            {
            }

            public bool ValidPathPatternPerTeam(List<Spot> Path, string Team)
            {
                if (Path.Count == 2)
                {
                    return Path[1].Occupants.Count == 0;
                }
                else
                { int i = 1;
                    while (i < Path.Count - 1)
                    {
                        if (i % 2 == 0 && Path[i].Occupants.Count != 0)
                        {
                            return false;
                        }
                        else if (Path[i].Occupants.Count == 0 && i % 2 != 0)
                        {
                            return false;
                        }
                        else if (i % 2 != 0 && Path[i].Occupants[0].ID.Contains(Team))
                        {
                            return false;
                        }
                        i += 1;
                    }
                    return Path[i].Occupants.Count == 0;
                }

            }

            public void Jump(List<Spot> path)
            {
                Disc occu = Occupants[0];
                int i = 0;
                while (i < path.Count - 1)
                {
                    path[i].Occupants.Clear();
                    i += 1;
                }
                path[i].Occupants.Clear();
                path[i].Occupants.Add(occu);
            }

        }
        public class Disc
        {
            public string ID;
            public Disc(string id)
            {
                ID = id;
            }

            public void KingMe()
            {
                ID = "K" + ID;
            }
        }
    }
}
