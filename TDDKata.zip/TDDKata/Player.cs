﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TDDKata1
{
    public class Player
    {
        public string Colour;
        public  Random myDice;
        public List<Peg> Pegs;
        public List<List<Peg>> Path = new List<List<Peg>> { };

        public Player(string c = "Blank")
        {
            myDice = new Random();
            Colour = c;
            Pegs = new List<Peg> { new Peg(Colour, 1), new Peg(Colour, 2), new Peg(Colour, 3), new Peg(Colour, 4) };
            FillPath();
        }

        public int Roll()
        {
            return myDice.Next(1, 7);
        }

        public void FillPath()
        {
            for (int i = 0; i < 57; i++)
            {
                Path.Add(new List<Peg> { });
            }
        }

    }

    public class Peg
    {
        string ID;
        public int Location; 

        public Peg(string Colour, int id)
        {
            ID = Colour + id.ToString();
            Location = 0;
        }

        public void Move(int destination)
        {
            Location += 5;
        }
    }
}
