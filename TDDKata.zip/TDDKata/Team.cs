﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TDDKata1
{
    public class Team
    {
        private string Name;
        private List<Employee> TeamMembers;
        
        public Team(string _name, List<Employee> teamMembers=null)
        {
            Name = _name;
            if (teamMembers == null)
                TeamMembers = new List<Employee>() { };
            else
                TeamMembers = teamMembers;
        }

        public List<Employee> GetTeamMembers()
        {
            return TeamMembers;
        }

        public void AddMember(Employee e)
        {
            TeamMembers.Add(e);
        }


        public string GetName()
        {
            {
                return Name;
            }
        }

        public string Display()
        {
            string result = String.Format("Team Name: {0}\nMembers:", Name);
            foreach (var e in TeamMembers)
            {
                result += "\n- " + e.Display();
            }
            return result;
        }

        public void RemoveMember(string v)
        {
            for (int i = 0; i < TeamMembers.Count; i++)
            {
                if (TeamMembers[i].name.ToLower() == v.ToLower())
                {
                    TeamMembers.Remove(TeamMembers[i]);
                }
            }
        }

        public Employee FindEmployee(string v)
        {
            foreach (Employee E in TeamMembers)
            {
                if (E.Alias.ToLower() == v.ToLower() || E.name.ToLower() == v.ToLower())
                {
                    return E;
                }
            }
            return null;
        }
    }
}
