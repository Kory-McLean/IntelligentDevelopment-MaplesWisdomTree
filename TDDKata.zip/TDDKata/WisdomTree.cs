﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Input
    ;
using System.Threading;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Diagnostics;

namespace TDDKata1
{
    public class WisdomTree
    {
        private List<Team> Teams;
        private List<string> Quotes = new List<string>() {"\"Once you replace negative thoughts with positive ones, you'll start having positive results.\" Willie Nelson", "\"You can't be paralyzed by fear of failure or you will never push yourself.\" Arnold Schwarzenegger", "\"If you stumble make it part of the dance.\" Unknown", "\"Do one thing every day that scares you.\" Eleanor Roosevelt" };
        private List<string> Keywords = new List<string>() { "find", "where", "who" ,"get", "what", "add", "edit", "set", "open", "help"};
        private List<string> Properties = new List<string>() { "name", "birthday", "position", "email", "alias", "hobbies", "besties", "availability" };
        private Dictionary<string, Game> Games = new Dictionary<string, Game>();
        private Dictionary<string, Application> Applications = new Dictionary<string, Application>();
        private Dictionary<string, string> Positions = new Dictionary<string, string>();
        private Dictionary<string, string> Accounts = new Dictionary<string, string>();
        private Employee curEmp;

        public WisdomTree()
        {
            Teams = new List<Team>();
            Positions.Add("developers", "developer");
            Positions.Add("interns", "intern");
            Positions.Add("testers", "tester");
            Positions.Add("BAs", "BA");
            Positions.Add("SMs", "SM");
            Games.Add("superspaceshooters", new Game("Super Space Shooter", "C:\\Users\\KQM\\Desktop\\Games\\SpaceShooter\\indexSS.html"));
            Games.Add("blasterfight", new Game("Blaster Fight", "C:\\Users\\KQM\\Desktop\\Games\\BlasterFight\\IndexBF.html"));
            Games.Add("frogger", new Game("Frogger", "C:\\Users\\KQM\\Desktop\\Games\\Frogger\\indexEasy.html"));
            Applications.Add("darwin", new Application("Darwin"));
            Applications["darwin"].AddSummary("One of Maples primary services is the provision and management of companies for our clients. We need a \nsystem that allows us to track the registers, charge fees and store key information for those companies. This is Darwin's job.");
            Applications["darwin"].SetUserGuideLink("http://moogle/IT/Guides_Manuals_and_Tips/User%20Guide%20-%20Darwin%20-%20General%20Corporate%20Administration.pdf");
            Employee KQM = new Employee("Kory McLean", "June 6th", "Intern", "kory.mclean@maplesandcalder.com", "KQM");
            Employee HYS = new Employee("Hasani Stewart", "June 25th", "Intern", "hasani.stewart@maplesandcalder.com", "HYS");
            Employee GGB = new Employee("George Blake", "July 6th", "Developer", "george.blake@maplesandcalder.com", "GGB");
            Employee DUC = new Employee("David Campbell", "January 1st", "Developer", "david.campbell@maplesandcalder.com", "DUC");
            Team Raptors01 = new Team("Raptors01", new List<Employee>() { KQM, HYS, GGB, DUC });
            AddTeam(Raptors01);
        }
        public Dictionary<string,  string> GetAccounts()
        {
            return Accounts;
        }
        public Employee GetCurEmp()
        {
            return curEmp;
        }
        public void LogOn(string username, string password)
        {
            if (Accounts[username.ToLower()] == password)
            {
                curEmp = FindEmployee(username);
            }
        }

        public void RegisterAccount(string username, string password)
        {
            if (Accounts.ContainsKey(username))
            {
                Console.WriteLine("This Username is already in use");
            }
            else
            {
                Accounts[username] = password;
            }
        }

        public void AddTeam(Team _team)
        {
            Teams.Add(_team);
        }
        
        public List<Employee> GetPositionHolders(string p)
        {
            List<Employee> result = new List<Employee>() { };
            foreach (Team T in Teams)
            {
                foreach (Employee E in T.GetTeamMembers())
                {
                    if (E.position.ToLower() == p.ToLower())
                    {
                        result.Add(E);
                    }
                }
            }
            return result;
        }

        public string DisplayPositionHolder(List<Employee> l)
        {
            string result = "";
            foreach (Employee e in l)
            {
                result += e.Display() + "\n";
            }
            return result;
        }

        public string DisplayTeams()
        {
            string result = "Teams:\n";
            foreach (Team t in Teams)
            {
                result += String.Format("- {0}\n", t.GetName());
            }
            return result.Trim();
        }

        public List<Team> GetTeams()
        {
            return Teams;
        }

        public Team FindTeam(string v)
        {
            foreach (Team T in Teams)
            {
                if (T.GetName().ToLower() == v.ToLower())
                {
                    return T;
                }
            }
            return null;
        }

        public Employee FindEmployee(string v)
        {
            foreach (Team T in Teams)
            {
                if (T.FindEmployee(v) != null)
                {
                   return T.FindEmployee(v);
                }
            }
            return null;
        }

        public string GetQuote()
        {
            Random rnd = new Random();
            return Quotes[rnd.Next(0, Quotes.Count)];
        }

        public bool IsKeyWord(string s)
        {
            foreach (string S in Keywords)
            {
                if (S == s.ToLower())
                {
                    return true;
                }
            }
            return false;
        }

        public string findResponse(string v)
        {
            if (FindTeam(v.Substring(5)) != null)
            {
                return FindTeam(v.Substring(5)).Display();
            }
            else if (v.Split()[1].ToLower() == "me")
            {
                return curEmp.Display();
            }
            else { return FindEmployee(v.Substring(5)) != null ? FindEmployee(v.Substring(5)).Display() : null;}
        }

        public string FindPositionInStr(string v)
        {
            string[] splitV = v.Split();
            foreach (string s in splitV)
            {
                if (Positions.Keys.Contains(s.ToLower()))
                {
                    return Positions[s];
                }
            }
            return null;
        }
        public Game FindGameInStr(string v)
        {
            string[] splitV = v.Split();
            foreach (string s in splitV)
            {
                if (Games.Keys.Contains(s.ToLower()))
                {
                    return Games[s];
                }
            }
            return null;
        }
        public Application FindAppInStr(string v)
        {
            string[] splitV = v.Split();
            foreach (string s in splitV)
            {
                if (Applications.Keys.Contains(s.ToLower()))
                {
                    return Applications[s];
                }
            }
            return null;
        }

        public void Start()
        {
            curEmp = null;
            Console.WriteLine("Please Enter 'Login' Or 'Register' Or Press Enter to contiue without loggin.");
            string decision = Console.ReadLine().ToLower().Trim();
            if (decision == "login")
            {
                int i = 0;
                do
                {
                    Console.Clear();
                    if (i > 0)
                    {
                        Console.WriteLine("Incorrect Combination!");
                    }
                    Console.WriteLine("Please enter your Username and then your Password\nUserName:");
                    string username = Console.ReadLine();
                    Console.WriteLine("Password:");
                    string password = Console.ReadLine();
                    LogOn(username, password);
                    i++;
                }
                while (curEmp == null);
            }
            else if (decision == "register")
            {
                do
                {
                    Console.Clear();
                    Console.WriteLine("Please enter your desired Username and then your Password\nUserName:");
                    string username = Console.ReadLine().ToLower();
                    while (Accounts.ContainsKey(username))
                    {
                        Console.WriteLine("Username Taken!\nTry Again\nUsername:");
                        username = Console.ReadLine().ToLower();
                    }
                    Console.WriteLine("Password:");
                    string password = Console.ReadLine();
                    RegisterAccount(username, password);
                    LogOn(username, password);
                }
                while (curEmp == null);
            }
                do
                {
                    Console.Clear();
                    Console.WriteLine("Hello, What can the Wisdom Tree help you with today?(Enter \"Help\" for help and instructions)");
                    string answer = Console.ReadLine().ToLower().Trim();
                    var splitAnswer = answer.Split();
                    while (!IsKeyWord(splitAnswer[0]))
                    {
                        Console.WriteLine("Sorry I don't understand what you want. Please try Again");
                        answer = Console.ReadLine();
                        splitAnswer = answer.Split();
                    }
                    if (answer == "help")
                    {
                        Console.WriteLine("\nWelcome to Maple's Leafy McBranch's  Wisdom Tree your Console that helps you gain, add or edit information about" +
                                          "\npeople within the office, applications aswell as just making your work hours just a tad less stressfull. The Tree" +
                                          "\nWorks by annalysing the commands you give it and picking out certain key words, such as 'find', 'what', 'get', 'who'" +
                                          "\nand 'open' just to name a few. When it comes to adding and editing make sure you specify what you wanna edit not who" +
                                          "\n, but fear not most functions include clues and instructions to follow. As the tree's knowledge is only as good as your" +
                                          "\nspelling be sure to spell things correctly to avoid error. Have fun and enjoy your new favourite tool. After completing a" +
                                          "\ntask simply type 'Thank you' to return to the main screen" +
                                          "\n\n Press Enter to continue or type 'Thank you' to finish.");
                    }
                    else if (splitAnswer[0].ToLower() == "find")
                    {
                        while (answer != "" && findResponse(answer) == null)
                        {
                            Console.WriteLine("Sorry '" + answer + "' returned null. Try again");
                            answer = Console.ReadLine();
                            splitAnswer = answer.Split();
                        }
                        Console.WriteLine(answer == "" ? "" : findResponse(answer));
                    }
                    else if ("get what".Contains(splitAnswer[0].ToLower()) && answer.Contains("quote"))
                    {
                        Console.WriteLine(GetQuote());
                    }
                    else if (splitAnswer[0].ToLower() == "where")
                    {
                        while (FindEmployee(splitAnswer[2]) == null && FindEmployee(splitAnswer[2] + " " + splitAnswer[3]) == null)
                        {
                            Console.WriteLine("Sorry '" + answer + "' returned null as we can only tell the location of Individuals not teams \nTry again. Make sure spelling is correct");
                            answer = Console.ReadLine();
                            splitAnswer = answer.Split();
                        }
                        if (splitAnswer.Count() > 3)
                        {
                            Console.WriteLine(FindEmployee(splitAnswer[2] + " " + splitAnswer[3]).DisplayAvailabilityFlag());

                        }
                        else
                        {
                            Console.WriteLine(FindEmployee(splitAnswer[2]).DisplayAvailabilityFlag());
                        }

                    }
                    else if (answer == "who are you")
                    {
                        Console.WriteLine("\nI am not a enigma, I am THE enigma.\nI am past, present and future.\nI am here while not here." +
                            "\nI am not trying to give an image of a fairytale, perfect, everything else, I am just being myself." +
                            "\nI see all but yet I cannot see" +
                            "\nBeing myself is what got me to where I am." +
                            "\nAnd it is what will take me to where I need to be." +
                            "\n- Leafy McBranch 2017");
                    }
                    else if (answer == "who am i")
                {
                    if (curEmp == null)
                    {
                        Console.WriteLine("You're no one, Return to the Main menu then login to become someone");
                    }
                    else
                    {
                        Console.WriteLine(String.Format("You are {0}, but you're nothing but a {1}\n{2}\n{3}", curEmp.name, curEmp.position, curEmp.DisplayHobbies(), curEmp.DisplayBesties()));
                    }
                    }
                    else if ("who get".Contains(splitAnswer[0].ToLower()))
                    {
                        while (FindPositionInStr(answer) == null)
                        {
                            Console.WriteLine("Sorry '" + answer + "' returned null Try again. Make sure spelling is correct");
                            answer = Console.ReadLine();
                            splitAnswer = answer.Split();
                        }
                        Console.WriteLine(DisplayPositionHolder(GetPositionHolders(FindPositionInStr(answer))));
                    }

                    else if (answer.Contains("add") && answer.Contains("team"))
                    {
                        Console.WriteLine("Please Enter the desire details of the new team in the following format:\n'Team Name'");
                        Teams.Add(new Team(Console.ReadLine()));
                    }
                    else if (answer.Contains("add") && answer.Contains("employee"))
                    {
                        Console.WriteLine("Please Enter the desire details of the new team in the following format:\n'Name' 'Birthday(ex June 1st)' 'Position' 'Email' 'Alias' 'Team'");
                        string empDetails = Console.ReadLine();
                        string[] empArray = empDetails.Split();
                        Employee newEmp = new Employee(empArray[0] + " " + empArray[1], empArray[2] + " " + empArray[3], empArray[4], empArray[5], empArray[6]);
                        FindTeam(empArray[7]).AddMember(newEmp);
                    }
                    else if (answer.Contains("edit") && answer.Contains("employee"))
                    {
                        Console.WriteLine("Please enter the Alias or Name of the employee you want to edit");
                        string criteriaEmp = Console.ReadLine();
                        Employee emp = FindEmployee(criteriaEmp);
                        while (emp == null)
                        {
                            Console.WriteLine("Sorry '" + criteriaEmp + "' returned null Try again. Make sure spelling is correct");
                            criteriaEmp = Console.ReadLine();
                            emp = FindEmployee(criteriaEmp);
                        }
                        Console.WriteLine(emp.Display() + "\n");
                        Console.WriteLine("PLease Enter a Property to edit:\nName\nBirthday\nPostion\nEmail\nAlias\nHobbies\nBesties\nAvailability");
                        string prop = Console.ReadLine().ToLower();
                        while (!Properties.Contains(prop))
                        {
                            Console.WriteLine("Sorry I do not understand. PLease Try again make sure spelling is correct");
                            prop = Console.ReadLine();
                        }
                        if (prop == "hobbies")
                        {
                            Console.WriteLine(emp.DisplayHobbies() + "\n Please Enter How you want to edit hobbies in the following format:\n 'add swimming videoGames delete cricket'");
                            string[] hArray = Console.ReadLine().ToLower().Split();
                            EditHobbies(emp, hArray);
                        }
                        else if (prop == "besties")
                        {
                            Console.WriteLine(emp.DisplayBesties() + "\n\n Please Enter How you want to edit besties in the following format:\n 'add kqm george blake delete hys'");
                            string[] hArray = Console.ReadLine().ToLower().Split();
                            EditBesties(emp, hArray);
                        }
                        else if (prop == "availability")
                        {
                            Console.WriteLine(emp.DisplayAvailabilityFlag() + "\nPlease Enter what you'd like to set the flag too.");
                            emp.SetAvailabilityFlag(Console.ReadLine());
                        }
                    }
                    else if (answer.Contains("open"))
                    {
                        if (FindGameInStr(answer) != null)
                        {
                            FindGameInStr(answer).OpenGame();
                        }
                        else if (answer.Contains("wiki"))
                        {
                            Process.Start("http://devwiki/dashboard.action;jsessionid=2337FC6E7DC08522D8EB681EAA9300AB");
                        }
                        else if (answer.Contains("outlook") || answer.Contains("email"))
                        {
                            Process.Start("C:\\ProgramData\\Microsoft\\Windows\\Start Menu\\Programs\\Outlook 2016");
                        }
                        else
                        {
                            Process.Start("C:\\ProgramData\\Microsoft\\Windows\\Start Menu\\Programs\\" + answer.Substring(5));
                        }
                    }
                    else if (splitAnswer[0] == "what" && FindAppInStr(answer) != null)
                    {
                        Console.WriteLine(FindAppInStr(answer).GetSummary() + "\n\n Type help to open user guide");
                        if (Console.ReadLine().ToLower() == "help")
                        {
                            Process.Start(FindAppInStr(answer).GetUserGuideLink());
                        }
                    }
                } while (Console.ReadLine().ToLower() != "thank you");
        }

        void EditHobbies(Employee e, string[] hArray)
        {
            for (int i = 0; i < hArray.Count(); i++)
            {
                if (hArray[i] == "add")
                {
                    int x = 1;
                    while (hArray.Count() > (x + i) && hArray[i + x] != "delete")
                    {
                        e.AddHobby(hArray[i + x]);
                        x++;
                    }
                }
                else if (hArray[i] == "delete")
                {
                    int x = 1;
                    while (hArray.Count() > (x + i) && hArray[i + x] != "add")
                    {
                        e.RemoveHobby(hArray[i + x]);
                        x++;
                    }
                }
            }
        }

        void EditBesties(Employee e, string[] hArray)
        {
            for (int i = 0; i < hArray.Count(); i++)
            {
                if (hArray[i] == "add")
                {
                    int x = 1;
                    while (hArray.Count() > (x + i) && hArray[i + x] != "delete")
                    {
                        e.AddBesties(FindEmployee(hArray[i + x]));
                        x++;
                    }
                }
                else if (hArray[i] == "delete")
                {
                    int x = 1;
                    while (hArray.Count() > (x + i) && hArray[i + x] != "add")
                    {
                        e.RemoveBestie(FindEmployee(hArray[i + x]));
                        x++;
                    }
                }
            }
        }
    }
}
