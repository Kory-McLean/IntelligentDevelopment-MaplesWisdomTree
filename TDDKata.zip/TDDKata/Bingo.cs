﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace TDDKata1
{
    public class Bingo
    {
        List<int> Availiblevaluelist = ProduceValueList();
        List<int> Calledvaluelist = new List<int> { 0 };
        public Bingo()
        {

        }
        public void Start()
        {
            Availiblevaluelist = ProduceValueList();
            Console.WriteLine("Welcome to Bingo (I Hated this Kata)\nPlayer 1 Press Enter to collect your card.");
            Console.ReadLine();
            var player1card = CreateCard();
            Console.WriteLine("Player 2 Press Enter to Collect your Card.");
            Console.ReadLine();
            var player2card = CreateCard();
            Console.Clear();
            Console.WriteLine(String.Format("Player 1\n{0}\n\nPlayer 2\n{1}", PrintCard(player1card), PrintCard(player2card)));
            int count = 0;
            Console.WriteLine("Calls:");
            Availiblevaluelist = ProduceValueList();
            while (DeclareWinner(player1card) is false && DeclareWinner(player2card) is false)
            {
                CallNumber(1, 76);
                count += 1;
            }
            if (DeclareWinner(player1card))
            {
                Console.WriteLine("BINGO, Player 1 Wins!!");
                Console.WriteLine("Called values: " + PrintCalledValues());
                Console.WriteLine(count);
                Console.ReadLine();
            }
            else
            {
                Console.WriteLine("BINGO, Player 2 Wins!!");
                Console.WriteLine("Called values: " + PrintCalledValues());
                Console.WriteLine(count);
                Console.ReadLine();
            }


        }

        public static List<int> ProduceValueList()
        {
            List<int> list = new List<int> { };
            for (int i = 1; i < 76; i++)
            {
                list.Add(i);
            }
            return list;
        }

        public string PrintCalledValues()
        {
            string result = "";
            foreach (var item in Calledvaluelist)
            {
                result += item + " ";
            }
            return result.Trim();
        }

        public int CallNumber(int lower, int upper)
        {
            Random rand = new Random();
            int result = rand.Next(lower, upper);
            while (!Availiblevaluelist.Contains(result))
            {
                result = rand.Next(lower, upper);
            }
            Availiblevaluelist.Remove(result);
            Calledvaluelist.Add(result);
            return result;
        }

        public bool TestAllUniqueHelper()
        {
            List<int> list = new List<int> { };
            while (list.Count() < 75)
            {
                list.Add(CallNumber(1 ,76));
            }
            Availiblevaluelist = ProduceValueList();
            return list.Distinct().Count() == list.Count();
            
        }

        public bool CheckColumn(string v, int Lower, int Upper, List<List<string>> Card)
        {
            for (int i = 0; i < 5; i++)
            {
                if (int.Parse(Card["BINGO".IndexOf(v)][i]) == 0)
                {}
                else if (int.Parse(Card["BINGO".IndexOf(v)][i]) > Upper || int.Parse(Card["BINGO".IndexOf(v)][i]) < Lower)
                {
                    return false;
                }
            }
            return true;
        }

        public bool DeclareWinner(List<List<string>> card)
        {
            foreach (int item in ExtractNumbers(card))
            {
                if (!Calledvaluelist.Contains(item))
                {
                    return false;
                }
            }
            return true;
        }

        public List<List<string>> CreateCard()
        {
            var CardSheet = new List<List<string>> { };
            int lower = 1;
            int upper = 16;
            while (CardSheet.Count < 5)
            {
                var Column = new List<string> { };
                while (Column.Count < 5)
                {
                    if (Column.Count == 2 && CardSheet.Count == 2)
                    {
                        Column.Add("00");
                    }
                    else
                    {
                        var number = SetNumber(lower, upper);

                        Column.Add(number < 10 ? "0"+number.ToString() : number.ToString());
                    }
                }
                CardSheet.Add(Column);
                lower += 15;
                upper += 15;
            }
            return CardSheet;
        }

        public string PrintCard(List<List<string>> Card)
        {
            string result = "B| I| N| G| O\n";
            
            for (int x = 0; x < 5; x++)
            {
                result += String.Format("{0}-{1}-{2}-{3}-{4}\n",Card[0][x], Card[1][x], Card[2][x], Card[3][x],Card[4][x]);
            }
            return result;
        }

        public int SetNumber(int lower, int upper)

        {
            Random rand = new Random();
            int result = rand.Next(lower, upper);
            while (!Availiblevaluelist.Contains(result))
            {
                result = rand.Next(lower, upper);
            }
            Availiblevaluelist.Remove(result);
            return result;
        }

        public void SetCalledValues(List<int> Numbers)
        {
            Calledvaluelist = Numbers;
        }

        public List<int> ExtractNumbers(List<List<string>> Card)
        {
            List<int> result = new List<int> { };
            foreach (var column in Card)
            {
                foreach (string item in column)
                {
                    result.Add(int.Parse(item));
                }
            }
            return result;
        }
    }
}
