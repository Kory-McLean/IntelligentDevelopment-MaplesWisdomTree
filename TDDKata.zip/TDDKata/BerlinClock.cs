﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TDDKata1
{
    public class BerlinClock
    {
        public BerlinClock()
        {

        }
        public string GetSingle(string T, int start, string lightcolor)
        {
            string result = "";
            int time = int.Parse(T.Substring(start, 2));
            for (int i = 1; i <= time % 5; i++)
            {
                result += lightcolor;
            }

            while (result.Length < 4)
            {
                result += "O";
            }
            return result;
        }

        public string GetFiveMinutes(string T)
        {
            string result = "";
            int minutes = int.Parse(T.Substring(3, 2));
            for (int i = 1; i <= minutes / 5; i++)
            {
                if (i % 3 == 0)
                {
                    result += "R";
                }
                else
                {
                    result += "Y";
                }
            }

            while (result.Length < 11)
            {
                result += "O";
            }
            return result;
        }

        public string GetFiveHours(string T)
        {
            string result = "";
            int time = int.Parse(T.Substring(0, 2));
            for (int i = 1; i <= time / 5; i++)
            {
                result += "R";
            }

            while (result.Length < 4)
            {
                result += "O";
            }
            return result;
        }

        public string GetSeconds(string T)
        {
            return int.Parse(T.Substring(6, 2)) % 2 == 0 ? "Y" : "O";
        }

        public string ConvertToBerlin(string T)
        {
            return GetSeconds(T) + GetFiveHours(T) + GetSingle(T, 0, "R") + GetFiveMinutes(T) + GetSingle(T, 3, "Y");
        }

        public string ConvertToDigital(string B)
        {
            return String.Format("{0}:{1}:{2}", GetDigitalHours(B), GetDigitalMintues(B), GetDigitalSeconds(B));
        }

        private object GetDigitalSeconds(string b)
        {
            Random rand = new Random();
            int seconds = 0;
            do { seconds = rand.Next(0, 60); } while (seconds % 2 != 0);
            if (b[0] == 'Y')
            {
                if (seconds < 10)
                {
                    return "0" + seconds.ToString();
                }
                else { return seconds.ToString(); };
            }
            else
            {
                seconds += 1;
                if (seconds < 10)
                {
                    return "0" + seconds.ToString();
                }
                else { return seconds.ToString(); };
            }
        }

        private string GetDigitalMintues(string b)
        {
            int result = 0;
            foreach (var item in b.Substring(9, 11))
            {
                if (item != 'O')
                {
                    result += 5;
                }
            }
            foreach (var item in b.Substring(20,4))
            {
                if (item == 'Y')
                {
                    result += 1;
                }
            }
            return result < 10 ? "0" + result.ToString() : result.ToString();
        }

        private string GetDigitalHours(string b)
        {
            int result = 0;
            foreach (var item in b.Substring(1,4))
            {
                if (item == 'R')
                {
                    result += 5;
                }
            }
            foreach (var item in b.Substring(5, 4))
            {
                if (item == 'R')
                {
                    result += 1;
                }
            }
            return result < 10 ? "0" + result.ToString() : result.ToString();
        }
    }
}
