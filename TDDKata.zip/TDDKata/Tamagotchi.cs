﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.ComponentModel;

namespace TDDKata1
{
    public class Tamagotchi
    {
        public float fullness;
        public float hunger;
        public float tiredness;
        public float happiness;
        BackgroundWorker bw = new BackgroundWorker();

        public Tamagotchi(float _fullness = 100, float _tiredness = 0, float _happiness=100)
        {
            fullness = _fullness;
            SetHungerProportionalToFullness();
            tiredness = _tiredness;
            happiness = _happiness;
            ClampValues();
            Thread decayandupdateThread = new Thread(BackgroundJob);
            decayandupdateThread.Start();
        }

        private static float Clamp(float value, float min, float max)
        {
            return (value < min) ? min : (value > max) ? max : value;
        }

        public void Feed(float v)
        {
            fullness += v;
            SetHungerProportionalToFullness();
            ClampValues();
        }

        public void Sleep()
        {
            Random rnd = new Random();
            tiredness -= rnd.Next(25, 80);
            ClampValues();
        }


        public void DecayAndUpdate()
        {
            fullness -= 10;
            tiredness += 10;
            happiness -= 10;
            SetHungerProportionalToFullness();
        }

        public async void BackgroundJob()
        {
            while (true)
            {
                await Task.Delay(5000);
                DecayAndUpdate();
            }
            
        }

        public void Play()
        {
            happiness += 10;
            tiredness += 10;
            ClampValues();
        }

        public void Poop()
        {
            if (fullness > 20)
            {
                fullness -= 20;
            }
            ClampValues();
        }

        void ClampValues()
        {
            fullness = Clamp(fullness, 0f, 100f);
            hunger = Clamp(hunger, 0f, 100f);
            happiness = Clamp(happiness, 0f, 100f);
            tiredness = Clamp(tiredness, 0f, 100f);
        }

        void SetHungerProportionalToFullness()
        {
            hunger = 100 - fullness;
        }
    }
}
