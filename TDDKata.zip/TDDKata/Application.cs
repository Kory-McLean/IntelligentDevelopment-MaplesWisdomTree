﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TDDKata1
{
    public class Application
    {
        string name;
        private string summary;
        private string UserGuideLink;
        public Application(string _name)
        {
            name = _name;
        }

        public void AddSummary(string _summary)
        {
            summary = _summary;
        }

        public string GetSummary()
        {
            return summary;
        }

        public void SetUserGuideLink(string link)
        {
            UserGuideLink = link;
        }

        public string GetUserGuideLink()
        {
            return UserGuideLink;
        }
    }
}
