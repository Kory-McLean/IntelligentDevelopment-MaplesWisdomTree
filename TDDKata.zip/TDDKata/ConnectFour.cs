﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TDDKata1
{
    public class ConnectFour
    {
        public List<List<string>> Grid;
        public ConnectFour()
        {
            Grid = new List<List<string>> { };
            FillGrid();
        }

        public void Start()
        {
            Console.WriteLine("Welcome to Connect four. Player One you're R(Red), Player Two you're Y(Yellow)\nPress enter to move on.");
            Console.ReadLine();
            var CurColor = "Y";
            var WaitingColor = "R";
            var CurPlayer = "Player Two";
            var WaitingPlayer = "Player One";
            do
            {
                var spare = CurColor;
                CurColor = WaitingColor;
                WaitingColor = spare;
                var spareplayer = CurPlayer;
                CurPlayer = WaitingPlayer;
                WaitingPlayer = spareplayer;
                Console.Clear();
                Console.WriteLine("A|B|C|D|E|F|G");
                Console.WriteLine("=============");
                Console.WriteLine(GetPrintGrid());
                Console.WriteLine(String.Format("{0}, Please Enter The Column you wanna play", CurPlayer));
                var play = Console.ReadLine();
                while (!"ABCDEFG".Contains(play))
                {
                    Console.WriteLine("Please enter a valid Column");
                    play = Console.ReadLine();
                }
                PlaceToken(CurColor, play);
            } while (DetermineWinner() == "None");
            Console.Clear();
            Console.WriteLine(String.Format("We have a Winner, {0}({2})\n{1}", CurPlayer, GetPrintGrid(),CurColor)+"\n Press Enter to Exit");
            Console.ReadLine();
        }

        public void FillGrid()
        {
            while (Grid.Count < 6)
            {
                List<string> row = new List < string > { };
                while ( row.Count < 7)
                {
                    row.Add("O");
                }
                Grid.Add(row);
            }
        }

        public void PlaceToken(string Color, string Column)
        {
            
            Grid[FindRow(Column)][FindColumn(Column)] = Color;
        }  
        
        public int FindRow(string Column)
        {
            int column = FindColumn(Column);
            int row = 5;

            while (Grid[row][column] != "O")
            {
                row -= 1;
            }
            return row;
        }
        public int FindColumn(string Column)
        {
           return "ABCDEFG".IndexOf(Column.ToUpper());
        }

        public string DetermineWinner()
        {
            return (CheckHorizontal() + CheckVertical() + CheckForwardDiag() + CheckBackDiag()) == "" ? "None" : 
                CheckHorizontal() + CheckVertical() + CheckForwardDiag() + CheckBackDiag();
        }

        public string CheckHorizontal()
        {
            foreach (var row in Grid)
            {
                for (int i = 0; i < 3; i++)
                {
                    if ((row[i] == row[i + 1] && row[i + 1] == row[i + 2] && row[i + 2] == row[i + 3]) && row[i] != "O")
                    {
                        return row[i];
                    }
                }
            }
            return "";
        }

        public string CheckVertical()
        {
            for (int i = 0; i < 3; i++)
            {
                int x = 0;
                while (x < 6)
                {
                    if ((Grid[i][x] == Grid[i + 1][x] && Grid[i + 1][x] == Grid[i + 2][x] && Grid[i + 2][x] == Grid[i + 3][x]) && Grid[i][x] != "O")
                    {
                        return Grid[i][x];
                    }
                    x += 1;
                }
            }
            return "";
        }

        public string CheckBackDiag()
        {
            for (int i = 0; i < 3; i++)
            {
                for (int x = 0; x < 4; x++)
                {
                    if ((Grid[i][x] == Grid[i + 1][x + 1] && Grid[i + 1][x + 1] == Grid[i + 2][x + 2] && Grid[i + 2][x + 2] == Grid[i + 3][x + 3]) && Grid[i][x] != "O")
                    {
                        return Grid[i][x];
                    }
                }
            }
            return "";
        }

        public string CheckForwardDiag()
        {
            for (int i = 5; i > 2; i--)
            {
                for (int x = 0; x < 4; x++)
                {
                    if ((Grid[i][x] == Grid[i - 1][x + 1] && Grid[i - 1][x + 1] == Grid[i - 2][x + 2] && Grid[i - 2][x + 2] == Grid[i - 3][x + 3]) && Grid[i][x] != "O")
                    {
                        return Grid[i][x];
                    }
                }
            }
            return "";
        }

        public string GetPrintGrid()
        {
            string result = "";
            foreach (var item in Grid)
            {
                foreach (var str in item)
                {
                    result += str + "-";
                }
                result = result.Substring(0,result.Length - 1);  
                result += "\n";
            }
            return result;
        }
    }
}
