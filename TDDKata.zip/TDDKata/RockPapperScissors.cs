﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TDDKata
{

    public class RockPapperScissors
    {
        public RockPapperScissors()
        {

        }

        public string Play(string player1, string player2)
        {
            if (Player1Wins(player1, player2))
            {
                return DisplayWinner("Player1");
            }
            else if (Player2Wins(player1, player2))
            {
                return DisplayWinner("Player2");
            }
            return "Draw";
        }

        private static string DisplayWinner(string player)
        {
            return string.Format("{0} Wins.", player);
        }

        public bool Player1Wins(string play1, string play2)
        {
            List<string> Player1 = new List<string> { "rock", "scissors", "paper" };
            List<string> Player2 = new List<string> { "scissors", "paper", "rock" };
            return play2 == Player2[Player1.IndexOf(play1)];
        }

        public bool Player2Wins(string play1, string play2)
        {
            List<string> Player2 = new List<string> { "rock", "scissors", "paper" };
            List<string> Player1 = new List<string> { "scissors", "paper", "rock" };
            return play1 == Player1[Player2.IndexOf(play2)];
        }

        internal void Start()
        {
            int P1score = 0;
            int P2score = 0;
            int Draws = 0;
            int Rounds = 0;
            Console.WriteLine("Welcome to the Rock Paper Scissors Arena, Enter 'end' after a round to exit. \n Press Enter to Begin.");
            while (Console.ReadLine().ToLower() != "end")
            {
                Console.Clear();
                Console.WriteLine("Player 1 Enter your Name:");
                var player1 = Console.ReadLine();
                Console.WriteLine("Player 2 Enter your Name:");
                var player2 = Console.ReadLine();
                Console.WriteLine(String.Format("{0} Choose Your Weapon: ",player1));
                var play1 = Console.ReadLine().ToLower();
                Console.Clear();
                Console.WriteLine(String.Format("{0} Choose Your Weapon: ", player2));
                var play2 = Console.ReadLine().ToLower();
                Console.Clear();
                Console.WriteLine(Play(play1, play2));
                if (Player1Wins(play1, play2))
                {
                    P1score += 1;
                }
                else if (Player2Wins(play1, play2))
                {
                    P2score += 1;
                }
                else { Draws += 1; }
                Rounds += 1;
                string Score = String.Format(" {4}: {0} \n {5}: {1} \n Draws: {2} \n Round: {3}", P1score, P2score, Draws, Rounds, player1, player2);
                Console.WriteLine(Score + "\nPress Enter to Continue or End to Exit");
            }
        }
    }
}
