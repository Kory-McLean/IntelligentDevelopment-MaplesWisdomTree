﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TDDKata1
{
    public class Game
    {
        string Name;
        string filePath;
        public Game(string _name, string _filePath)
        {
            Name = _name;
            filePath = _filePath;
        }

        public string GetName()
        {
            return Name;
        }

        public string GetFilePath()
        {
            return filePath;
        }

        public void OpenGame()
        {
            System.Diagnostics.Process.Start(filePath);
        }
    }
}
