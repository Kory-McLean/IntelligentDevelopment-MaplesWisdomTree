﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TDDKata1
{
    public class Tennis
    {
        int player1;
        int player2;
        List<string> ScoreSystem;
        public List<string> ScoreSystemSetter { get => ScoreSystem; set => ScoreSystem = new List<string> { "0", "15", "30", "40", "A", "Winner"}; }

        public Tennis()
        {
            player1 = 0;
            player2 = 0;
            ScoreSystem = new List<string>{ "0", "15", "30", "40", "A", "Winner" };

        }
        
        //Used only for Testing
        public void SetScores(int Player1Score, int Player2Score)
        {
            player1 = Player1Score;
            player2 = Player2Score;

        }

        public string PointScored(int server)
        {
            if (server == 1)
            {
                player1 += 1;
                CheckAndCorrectDeuce();
                CheckAndProduceWinner();
            }
            else
            {
                player2 += 1;
                CheckAndCorrectDeuce();
                CheckAndProduceWinner();
            }
            return String.Format("Score: {0}-{1}", ScoreSystem[player1], ScoreSystem[player2]);
        }

        public void CheckAndCorrectDeuce()
        {
            if (player1 == 4 && player2 == 4)
            {
                player1 -= 1;
                player2 -= 1;
            }
        }

        public void CheckAndProduceWinner()
        {
            player1 = player1 - 2 == player2 ? 5 : player1;
            player2 = player2 - 2 == player1 ? 5 : player2;

        }

    }
}
