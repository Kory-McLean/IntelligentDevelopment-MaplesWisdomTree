﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TDDKata;
using TDDKata1;

 namespace GameConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            WisdomTree WT = new WisdomTree();
            do
            {
                Console.Clear();
                Console.WriteLine("Please Enter What game you wanna play.\n Rock Paper Scissors = RPS\n Fizz Buzz = FB\n Connect Four = C4\n Bingo = BIN\n Snakes and Ladders = SAL\nCheckers = CH\nWisdom Tree = WT");
                var answer = Console.ReadLine();
                if (answer == "RPS")
                {
                    Console.Clear();
                    RockPapperScissors Game = new RockPapperScissors();
                    Game.Start();
                }
                else if (answer == "FB")
                {
                    Console.Clear();
                    FizzBuzz Game = new FizzBuzz();
                    Game.Start();
                }
                else if (answer == "C4")
                {
                    Console.Clear();
                    ConnectFour Game = new ConnectFour();
                    Game.Start();
                }
                else if (answer == "BIN")
                {
                    Console.Clear();
                    Bingo Game = new Bingo();
                    Game.Start();
                }
                else if (answer == "SAL")
                {
                    Console.Clear();
                    Console.WriteLine("Welcome to Snakes and Ladders!\nPlease Enter the Number of Players you wish to have.");
                    SnakesAndLadders Game = new SnakesAndLadders(int.Parse(Console.ReadLine()));
                    Game.Start();
                }
                else if (answer == "CH")
                {
                    Console.Clear();
                    Checkers Game = new Checkers();
                    Game.Start();
                }
                else if (answer == "WT")
                {
                    Console.Clear();
                    WT.Start();
                }

                Console.WriteLine("Do you wanna play again? Please answer yes/no");
            } while (Console.ReadLine().ToLower() == "yes");
         

        }
    }
}