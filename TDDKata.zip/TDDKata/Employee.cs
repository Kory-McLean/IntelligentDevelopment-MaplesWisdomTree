﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TDDKata1
{
    public class Employee
    {
        public string name;
        string birthday;
        public string position;
        public string availability;
        public List<string> hobbies;
        public string Email;
        public string Alias;

        public List<Employee> Besties;

        public Employee(string _name, string _birthday, string _position, string _email, string _alias)
        {
            name = _name;
            birthday = _birthday;
            position = _position;
            availability = "Available";
            hobbies = new List<string>();
            Besties = new List<Employee>() { };
            Alias = _alias;
            Email = _email;

        }

        public string DisplayAvailabilityFlag()
        {
            return String.Format("{0} is currently {1}", name, availability);
        }
        public void SetAvailabilityFlag(string flag)
        {
            availability = flag;
        }

        public void AddHobby(string h)
        {
            hobbies.Add(h);
        }

        public void RemoveHobby(string h)
        {
            hobbies.Remove(h);
        }

        public string DisplayHobbies()
        {
            string result = String.Format("{0} enjoys ", name);
            if (hobbies.Count == 0)
                return "nothing";
            else if (hobbies.Count == 1)
            {
                return result + hobbies[0];
            }
            else
            {
                for (int i = 0; i < hobbies.Count - 1; i++)
                {
                    result += hobbies[i] + ", ";
                }
                result = result.Substring(0, result.Length - 2) + String.Format(" and {0}", hobbies[hobbies.Count - 1]);
                return result.Trim();
            }

        }

        public void AddBesties(Employee e)
        {
            Besties.Add(e);
        }

        public void RemoveBestie(Employee v)
        {
            Besties.Remove(v);
        }

        public string DisplayBesties()
        {
            string result = String.Format("{0} has {1} Bestie/Besties - ", name, Besties.Count);
            if (Besties.Count == 0)
            {
                return "No one";
            }
            else if (Besties.Count == 1)
            {
                return result + Besties[0].name;
            }
            else
            {
                for (int i = 0; i < Besties.Count - 1; i++)
                {
                    result += String.Format("{0}, ", Besties[i].name);
                }
                result = result.Substring(0, result.Length - 2) +" and " + Besties[Besties.Count - 1].name;
                return result;
            }
        }

        public string Display()
        {
            return String.Format("{0} ({1}) Email: {2} | Alias: {3} | Birthday: {4}", name, position, Email, Alias, birthday);
        }
    }
}
