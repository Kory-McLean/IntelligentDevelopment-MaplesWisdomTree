﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TDDKata
{
    public class RomanNumerals
    {
        public RomanNumerals()
        {

        }

        public string TranslateToRoman(int number)
        {
            if (DetermineNumeral(number) != "")
                return DetermineNumeral(number);
            else
            {
                string result = "";
                int remainder = number % 5;
                int FiveScale = number / 5;
                while (FiveScale != 0)
                {
                    if (DetermineNumeral(FiveScale * 5) != "")
                        return DetermineNumeral(FiveScale * 5) + TranslateToRoman(remainder);
                    else
                        FiveScale -= 1;
                    remainder += 5;
                }
                return result + String.Concat(Enumerable.Repeat("I", number));
            }
        }
        private static string DetermineNumeral(int number)
        {
            List<int> Numbers = new List<int> { 1, 2, 3, 4, 5, 9, 10, 40, 50, 90, 100, 400, 500, 900, 1000 };
            List<string> Romans = new List<string> { "I", "II", "III", "IV", "V", "IX", "X", "XL", "L", "XC", "C", "CD", "D", "CM", "M" };
            return Numbers.Contains(number) ? Romans[Numbers.IndexOf(number)] : "";
        }

        //-------------To Arabic----------------------------------------------------
        public int GetArabicValue(string Roman)
        {
            List<int> Numbers = new List<int> { 1, 2, 3, 4, 5, 9, 10, 40, 50, 90, 100, 400, 500, 900, 1000 };
            List<string> Romans = new List<string> { "I", "II", "III", "IV", "V", "IX", "X", "XL", "L", "XC", "C", "CD", "D", "CM", "M" };
            return Romans.Contains(Roman) ? Numbers[Romans.IndexOf(Roman)] : 0;
        }

        public int Calculate(string Roman)
        {
            
            if (GetArabicValue(Roman) != 0)
            {
                return GetArabicValue(Roman);
            }
            int index = 0;
            int sum = 0;
            while (index < Roman.Length - 1)
            {
                if (GetArabicValue(Roman.Substring(index, 2)) == 0)
                {
                    sum += GetArabicValue(Roman.Substring(index, 1));
                    index += 1;
                }
                else
                {
                    sum += GetArabicValue(Roman.Substring(index, 2));
                    index += 2;
                }
            }
            return index == Roman.Length - 1 ? sum + GetArabicValue(Roman.Substring(index)) : sum;
        }
    }
}
