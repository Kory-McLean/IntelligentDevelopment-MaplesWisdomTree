﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using TDDKata1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TDDKata1.Tests
{
    [TestClass()]
    public class ConnectFourTests
    {
        ConnectFour Game = new ConnectFour();
        [TestMethod()]
        public void ConnectFourTest()
        {
          ConnectFour Game = new ConnectFour();
        }

        [TestMethod()]
        public void TestPlaceToken()
        {
            Assert.AreEqual(1, Game.Grid.Count() - Game.FindRow("B"));
            Game.PlaceToken("B", "D");
            Game.PlaceToken("B", "D");
            Assert.AreEqual(3, Game.Grid.Count() - Game.FindRow("D"));
            Game.PlaceToken("B", "F");
            Game.PlaceToken("B", "F");
            Game.PlaceToken("B", "F");
            Game.PlaceToken("B", "F");
            Game.PlaceToken("B", "F");
            Assert.AreEqual(6, Game.Grid.Count() - Game.FindRow("F"));
        }

        [TestMethod()]
        public void DetermineWinnerHorrizontal()
        {
            ConnectFour Game = new ConnectFour();
            Game.PlaceToken("Y", "A");
            Game.PlaceToken("Y", "B");
            Game.PlaceToken("Y", "C");
            Game.PlaceToken("Y", "D");
            Assert.AreEqual("Y", Game.DetermineWinner());
        }

        [TestMethod()]
        public void DetermineWinnerVertical()
        {
            ConnectFour Game = new ConnectFour();
            Game.PlaceToken("R", "A");
            Game.PlaceToken("R", "A");
            Game.PlaceToken("R", "A");
            Game.PlaceToken("R", "A");
            Assert.AreEqual("R", Game.DetermineWinner());
        }

        [TestMethod()]
        public void DetermineWinnerEmpty()
        {
            ConnectFour Game = new ConnectFour();
            Assert.AreEqual("None", Game.DetermineWinner());
        }

        [TestMethod()]
        public void DetermineWinnerForwardDiag()
        {
            ConnectFour Game = new ConnectFour();
            Game.PlaceToken("R", "A");
            Game.PlaceToken("R", "A");
            Game.PlaceToken("Y", "A");
            Game.PlaceToken("R", "A");

            Game.PlaceToken("Y", "B");
            Game.PlaceToken("R", "B");
            Game.PlaceToken("Y", "B");
            Game.PlaceToken("Y", "B");

            Game.PlaceToken("R", "C");
            Game.PlaceToken("Y", "C");
            Game.PlaceToken("R", "C");
            Game.PlaceToken("R", "C");

            Game.PlaceToken("Y", "D");
            Game.PlaceToken("Y", "D");
            Game.PlaceToken("Y", "D");
            Game.PlaceToken("R", "D");

            Assert.AreEqual("R", Game.DetermineWinner());
        }
        [TestMethod()]
        public void DetermineWinnerBackDiag()
        {
            ConnectFour Game = new ConnectFour();
            Game.PlaceToken("R", "A");
            Game.PlaceToken("R", "A");
            Game.PlaceToken("Y", "A");
            Game.PlaceToken("Y", "A");

            Game.PlaceToken("Y", "B");
            Game.PlaceToken("R", "B");
            Game.PlaceToken("Y", "B");
            Game.PlaceToken("Y", "B");

            Game.PlaceToken("R", "C");
            Game.PlaceToken("Y", "C");
            Game.PlaceToken("R", "C");
            Game.PlaceToken("R", "C");

            Game.PlaceToken("Y", "D");
            Game.PlaceToken("R", "D");
            Game.PlaceToken("Y", "D");
            Game.PlaceToken("Y", "D");

            Assert.AreEqual("O-O-O-O-O-O-O\nO-O-O-O-O-O-O\nY-Y-R-Y-O-O-O\nY-Y-R-Y-O-O-O\nR-R-Y-R-O-O-O\nR-Y-R-Y-O-O-O\n", Game.GetPrintGrid());
            Assert.AreEqual("Y", Game.DetermineWinner());
        }


        [TestMethod()]
        public void TestPrintGrid()
        {
            ConnectFour Game = new ConnectFour();
            Game.PlaceToken("R", "A");
            Game.PlaceToken("R", "A");
            Game.PlaceToken("Y", "A");
            Game.PlaceToken("R", "A");

            Game.PlaceToken("Y", "B");
            Game.PlaceToken("R", "B");
            Game.PlaceToken("Y", "B");
            Game.PlaceToken("Y", "B");

            Game.PlaceToken("R", "C");
            Game.PlaceToken("Y", "C");
            Game.PlaceToken("R", "C");
            Game.PlaceToken("R", "C");

            Game.PlaceToken("Y", "D");
            Game.PlaceToken("Y", "D");
            Game.PlaceToken("Y", "D");
            Game.PlaceToken("R", "D");

            Assert.AreEqual("O-O-O-O-O-O-O\nO-O-O-O-O-O-O\nR-Y-R-R-O-O-O\nY-Y-R-Y-O-O-O\nR-R-Y-Y-O-O-O\nR-Y-R-Y-O-O-O\n", Game.GetPrintGrid());
        }
    }
}