﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using TDDKata1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TDDKata1.Tests
{
    [TestClass()]
    public class WisdomTreeTests
    {
        Employee KQM = new Employee("Kory McLean", "June 6th", "Intern", "kory.mclean@maplesandcalder.com", "KQM");
        Employee HYS = new Employee("Hasani Stewart", "January 1st", "Intern", "hasani.stewart@maplesandcalder.com", "HYS");
        Employee GGB = new Employee("George Blake", "January 1st", "Developer", "george.blake@maplesandcalder.com", "GGB");
        Employee DUC = new Employee("David Campbell", "January 1st", "Developer", "david.campbell@maplesandcalder.com", "DUC");

        WisdomTree WT = new WisdomTree();
        [TestMethod()]
        public void CreateWisdomTreeTest()
        {
            WisdomTree WT = new WisdomTree();
        }

        [TestMethod]
        public void TestAddTeam()
        {
            Team Raptors01 = new Team("Raptors01", new List<Employee>() { KQM, HYS, GGB, DUC });
            Team Vipers = new Team("Vipers");
            WT.AddTeam(Raptors01);
            WT.AddTeam(Vipers);
            Assert.AreEqual(2, WT.GetTeams().Count);
        }

        [TestMethod]
        public void TestDisplayTeams()
        {
            Team Raptors = new Team("Raptors", new List<Employee>() { KQM, HYS, GGB, DUC });
            Team Vipers = new Team("Vipers");
            WT.AddTeam(Raptors);
            WT.AddTeam(Vipers);
            Assert.AreEqual("Teams:\n- Raptors\n- Vipers", WT.DisplayTeams());
        }

        [TestMethod]
        public void TestFindTeam()
        {
            Team Raptors01 = new Team("Raptors01", new List<Employee>() { KQM, HYS, GGB, DUC });
            Team Vipers = new Team("Vipers");
            WT.AddTeam(Raptors01);
            WT.AddTeam(Vipers);
            Assert.AreEqual(Raptors01, WT.FindTeam("Raptors01"));
            Assert.AreEqual(Vipers, WT.FindTeam("Vipers"));
            Assert.AreEqual(null, WT.FindTeam("So Solid"));
        }

        [TestMethod]
        public void TestFindEmployee()
        {
            Team Raptors = new Team("Raptors", new List<Employee>() { KQM, HYS, GGB, DUC });
            Team Vipers = new Team("Vipers");
            WT.AddTeam(Raptors);
            WT.AddTeam(Vipers);
            Assert.AreEqual(GGB, WT.FindEmployee("GGB"));
            Assert.AreEqual(KQM, WT.FindEmployee("kory mclean"));
        }

        [TestMethod]
        public void TestGenerateQuoteOfDay()
        {
            Assert.IsNotNull(WT.GetQuote());
        }

        [TestMethod]
        public void TestIsKeyWord()
        {
            Assert.IsFalse(WT.IsKeyWord("Peanut"));
            Assert.IsTrue(WT.IsKeyWord("Find"));
            Assert.IsTrue(WT.IsKeyWord("who"));
            Assert.IsFalse(WT.IsKeyWord("Wheere"));
        }

        [TestMethod]
        public void TestFindResponse()
        {
            Team Raptors01 = new Team("Raptors01", new List<Employee>() { KQM, HYS, GGB, DUC });
            WT.AddTeam(Raptors01);
            string ans1 = "Find Kory McLean";
            string ans2 = "Find Hasani Stewart";
            string ans3 = "find Geeroge Blakee";
            string ans4 = "find raptors01";
            string ans5 = "find vipors";

            Assert.IsNull(WT.findResponse(ans5));
            Assert.AreEqual("Kory McLean (Intern) Email: kory.mclean@maplesandcalder.com | Alias: KQM | Birthday: June 6th", WT.findResponse(ans1));
            Assert.AreEqual("Hasani Stewart (Intern) Email: hasani.stewart@maplesandcalder.com | Alias: HYS | Birthday: January 1st", WT.findResponse(ans2));
            Assert.IsNotNull(WT.findResponse(ans4));
            Assert.IsNull(WT.findResponse(ans3));
        }

        [TestMethod]
        public void RegisterTest()
        {
            Assert.IsNull(WT.GetCurEmp());
            Assert.IsTrue(WT.GetAccounts().Count() == 0);
            WT.RegisterAccount("KQM", "koryMclean");
            Assert.IsTrue(WT.GetAccounts().Count() == 1);
        }

        [TestMethod]
        public void TestLogOn()
        {
            Assert.IsNull(WT.GetCurEmp());
            Team Raptors01 = new Team("Raptors01", new List<Employee>() { KQM, HYS, GGB, DUC });
            WT.AddTeam(Raptors01);
            WT.RegisterAccount("KQM", "koryMclean");
            WT.LogOn("KQM", "koryMclean");
            Assert.AreEqual(KQM, WT.GetCurEmp());
        }
    }
}