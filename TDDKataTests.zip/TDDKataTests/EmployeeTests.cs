﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using TDDKata1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TDDKata1.Tests
{
    [TestClass()]
    public class EmployeeTests
    {
        Employee employee = new Employee("Kory McLean", "June 6th", "Intern", "kory.mclean@maplesandcalder.com" ,"KQM");
        [TestMethod()]
        public void CreateANewEmployeeTest()
        {
            Employee employee = new Employee("Kory McLean", "June 6th", "Intern", "kory.mclean@maplesandcalder.com", "KQM");
        }

        [TestMethod()]
        public void SetAvailabilityFlagTest()
        {
            Assert.AreEqual("Available", employee.availability);
            employee.SetAvailabilityFlag("Break");
            Assert.AreEqual("Break", employee.availability);
        }

        [TestMethod]
        public void ReturnHobbies()
        {
            employee.hobbies.AddRange(new List<string>() { "Football", "Video Games" });
            Assert.AreEqual("Football", employee.hobbies[0]);
            employee.AddHobby("Listening to Music");
            Assert.AreEqual(3, employee.hobbies.Count());
            Assert.AreEqual("Kory McLean enjoys Football, Video Games and Listening to Music", employee.DisplayHobbies());
        }

        [TestMethod]
        public void BestiesTesting()
        {
            Employee HYS = new Employee("Hasani Stewart", "January 1st", "Intern", "hasani.stewart@maplesandcalder.com", "HYS");
            Employee GGB = new Employee("George Blake", "January 1st", "Developer", "george.blake@maplesandcalder.com", "GGB");
            Employee DUC = new Employee("David Campbell", "January 1st", "Developer", "david.campbell@maplesandcalder.com", "DUC");
            Assert.AreEqual(0, employee.Besties.Count);
            employee.Besties.AddRange(new List<Employee>() {HYS, GGB});
            employee.AddBesties(DUC);
            Assert.AreEqual(3, employee.Besties.Count);
            Assert.AreEqual("Kory McLean has 3 Bestie/Besties - Hasani Stewart, George Blake and David Campbell", employee.DisplayBesties());
        }

        [TestMethod]
        public void DisplayEmployeeTest()
        {
            Employee HYS = new Employee("Hasani Stewart", "January 1st", "Intern", "hasani.stewart@maplesandcalder.com", "HYS");
            Assert.AreEqual("Hasani Stewart (Intern) Email: hasani.stewart@maplesandcalder.com | Alias: HYS | Birthday: January 1st", HYS.Display());
        }

        [TestMethod]
        public void AddHobbyTest()
        {
            Assert.AreEqual(0, employee.hobbies.Count());
            employee.AddHobby("Football");
            Assert.AreEqual(1, employee.hobbies.Count());
        }

        [TestMethod]
        public void RemoveHobbyTest()
        {
            Assert.AreEqual(0, employee.hobbies.Count());
            employee.AddHobby("Football");
            Assert.AreEqual(1, employee.hobbies.Count());
            employee.AddHobby("VideoGames");
            Assert.AreEqual(2, employee.hobbies.Count());
            employee.RemoveHobby("Football");
            Assert.AreEqual(1, employee.hobbies.Count());
        }

        [TestMethod]
        public void AddBestieTest()
        {
            Employee HYS = new Employee("Hasani Stewart", "January 1st", "Intern", "hasani.stewart@maplesandcalder.com", "HYS");
            Assert.AreEqual(0, employee.Besties.Count());
            employee.AddBesties(HYS);
            Assert.AreEqual(1, employee.Besties.Count());
        }

        [TestMethod]
        public void RemoveBestieTest()
        {
            Employee HYS = new Employee("Hasani Stewart", "January 1st", "Intern", "hasani.stewart@maplesandcalder.com", "HYS");
            Employee GGB = new Employee("George Blake", "January 1st", "Developer", "george.blake@maplesandcalder.com", "GGB");
            Assert.AreEqual(0, employee.Besties.Count());
            employee.AddBesties(HYS);
            Assert.AreEqual(1, employee.Besties.Count());
            employee.AddBesties(GGB);
            Assert.AreEqual(2, employee.Besties.Count());
            employee.RemoveBestie(HYS);
            Assert.AreEqual(1, employee.Besties.Count());
        }
    }
}