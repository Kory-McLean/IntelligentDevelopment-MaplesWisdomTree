﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using TDDKata1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TDDKata1.Tests
{
    [TestClass()]
    public class BerlinClockTests
    {
        BerlinClock Clock = new BerlinClock();
        [TestMethod()]
        public void TestSingleMinutesRow()
        {
            Assert.AreEqual("OOOO", Clock.GetSingle("00:00:00", 3, "Y"));
            Assert.AreEqual("YYYY", Clock.GetSingle("23:59:59", 3, "Y"));
            Assert.AreEqual("YYOO", Clock.GetSingle("12:32:00", 3, "Y"));
            Assert.AreEqual("YYYY", Clock.GetSingle("12:34:00", 3, "Y"));
            Assert.AreEqual("OOOO", Clock.GetSingle("12:35:00", 3, "Y"));

        }

        [TestMethod()]
        public void TestFiveMinutesRow()
        {
            Assert.AreEqual("OOOOOOOOOOO", Clock.GetFiveMinutes("00:00:00"));
            Assert.AreEqual("YYRYYRYYRYY", Clock.GetFiveMinutes("23:59:59"));
            Assert.AreEqual("OOOOOOOOOOO", Clock.GetFiveMinutes("12:04:00"));
            Assert.AreEqual("YYRYOOOOOOO", Clock.GetFiveMinutes("12:23:00"));
            Assert.AreEqual("YYRYYRYOOOO", Clock.GetFiveMinutes("12:35:00"));
        }

        [TestMethod()]
        public void TestSingleHoursRow()
        {
            Assert.AreEqual("OOOO", Clock.GetSingle("00:00:00", 0, "R"));
            Assert.AreEqual("RRRO", Clock.GetSingle("23:59:59", 0, "R"));
            Assert.AreEqual("RROO", Clock.GetSingle("02:04:00", 0, "R"));
            Assert.AreEqual("RRRO", Clock.GetSingle("08:23:00", 0, "R"));
            Assert.AreEqual("RRRR", Clock.GetSingle("14:35:00", 0, "R"));
        }

        [TestMethod()]
        public void TestFiveHoursRow()
        {
            Assert.AreEqual("OOOO", Clock.GetFiveHours("00:00:00"));
            Assert.AreEqual("RRRR", Clock.GetFiveHours("23:59:59"));
            Assert.AreEqual("OOOO", Clock.GetFiveHours("02:04:00"));
            Assert.AreEqual("ROOO", Clock.GetFiveHours("08:23:00"));
            Assert.AreEqual("RRRO", Clock.GetFiveHours("16:35:00"));
        }

        [TestMethod()]
        public void TestSeconds()
        {
            Assert.AreEqual("Y", Clock.GetSeconds("00:00:00"));
            Assert.AreEqual("O", Clock.GetSeconds("23:59:59	"));
        }

        [TestMethod()]
        public void TestEntireBerlinClock()
        {
            Assert.AreEqual("YOOOOOOOOOOOOOOOOOOOOOOO", Clock.ConvertToBerlin("00:00:00"));
            Assert.AreEqual("ORRRRRRROYYRYYRYYRYYYYYY", Clock.ConvertToBerlin("23:59:59"));
            Assert.AreEqual("YRRROROOOYYRYYRYYRYOOOOO", Clock.ConvertToBerlin("16:50:06"));
            Assert.AreEqual("ORROOROOOYYRYYRYOOOOYYOO", Clock.ConvertToBerlin("11:37:01"));
        }

        /* These  Tests Work, just dont know how they want me to calculate the seconds
[TestMethod()]
public void TestConvertToDigital()
{
   Assert.AreEqual("00:00:00", Clock.ConvertToDigital("YOOOOOOOOOOOOOOOOOOOOOOO"));
   Assert.AreEqual("23:59:59", Clock.ConvertToDigital("ORRRRRRROYYRYYRYYRYYYYYY"));
   Assert.AreEqual("16:50:06", Clock.ConvertToDigital("YRRROROOOYYRYYRYYRYOOOOO"));
   Assert.AreEqual("11:37:01", Clock.ConvertToDigital("ORROOROOOYYRYYRYOOOOYYOO"));
}
*/
    }
}