﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using TDDKata1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace TDDKata1.Tests
{
    [TestClass()]
    public class TamagotchiTests
    {
        [TestMethod()]
        public void CreateNewTamogotchi()
        {
            Tamagotchi T = new Tamagotchi();
        }

        [TestMethod]
        public void FeedingTamagotchiTest()
        {
            Tamagotchi Tama = new Tamagotchi(50);
            Assert.IsTrue(Tama.hunger == 50 && Tama.fullness == 50);
            Tama.Feed(50);
            Assert.IsTrue(Tama.hunger == 0 && Tama.fullness == 100);
        }

        [TestMethod]
        public void PutTamagotchiToBedTest()
        {
            Tamagotchi Tama = new Tamagotchi(100, 100);
            Tama.Sleep();
            Assert.IsTrue(Tama.tiredness < 80);
        }

        [TestMethod]
        public void DecayAndUpdateTest()
        {
            Tamagotchi Tama = new Tamagotchi();
            Tama.DecayAndUpdate();
            Assert.IsTrue(Tama.fullness < 100);
            Assert.IsTrue(Tama.hunger > 0);
            Assert.IsTrue(Tama.tiredness > 0);
        }

        [TestMethod]
        public void ChangingNeedsTest()
        {
            Tamagotchi Tama = new Tamagotchi();
            Thread.Sleep(16000);
            Assert.AreEqual(70, Tama.fullness);
            Assert.AreEqual(30, Tama.tiredness);
            Assert.AreEqual(70, Tama.happiness);
            Assert.IsTrue(Tama.fullness < 100);
            Assert.IsTrue(Tama.hunger > 0);
            Assert.IsTrue(Tama.tiredness > 0);
        }

        [TestMethod]
        public void PlayWithTamagotchiTest()
        {
            Tamagotchi Tama = new Tamagotchi(100, 0, 50);
            Tama.Play();
            Assert.AreEqual(10, Tama.tiredness);
            Assert.AreEqual(60, Tama.happiness);
        }

        [TestMethod]
        public void TamagotchiPoopTest()
        {
            Tamagotchi Tama = new Tamagotchi();
            Tama.Poop();
            Assert.AreEqual(80, Tama.fullness);
        }

        [TestMethod]
        public void TamagotchiClampingTest()
        {
            Tamagotchi Tama = new Tamagotchi(-100, 300, -1);
            Assert.AreEqual(0, Tama.fullness);
            Assert.AreEqual(100, Tama.tiredness);
            Assert.AreEqual(0, Tama.happiness);
            Assert.AreEqual(100, Tama.hunger);
        }
    }
}