﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using TDDKata1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TDDKata1.Tests
{
    [TestClass()]
    public class PlayerTests
    {
        Player testee = new Player("Red");
        [TestMethod()]
        public void CreatePlayerTest()
        {
            Player testee = new Player("Red");
            Assert.AreEqual("Red", testee.Colour);
        }

        [TestMethod()]
        public void TestPlayerRoll()
        {
            Assert.IsTrue(1 <= testee.Roll() && testee.Roll() <= 6);
        }

        [TestMethod()]
        public void TestMovePeg()
        {
            Assert.AreEqual(0, testee.Pegs[1].Location);
            testee.Pegs[1].Move(5);
            Assert.AreEqual(5, testee.Pegs[1].Location);

        }
    }
}