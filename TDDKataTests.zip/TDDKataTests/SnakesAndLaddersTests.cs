﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using TDDKata1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TDDKata1.Tests
{
    [TestClass()]
    public class SnakesAndLaddersTests
    {
        SnakesAndLadders Game = new SnakesAndLadders(4);
        [TestMethod()]
        public void MoveTokenTest()
        {
            SnakesAndLadders Game = new SnakesAndLadders(4);
            Assert.AreEqual(1, Game.Tokens[0].location);
            Assert.AreEqual(1, Game.Tokens[1].location);
            Game.PlaceToken(Game.Tokens[1], 3);
            Assert.AreEqual(4, Game.Tokens[1].location);
            Assert.AreEqual(1, Game.Tokens[2].location);
            Game.PlaceToken(Game.Tokens[2], 3);
            Game.PlaceToken(Game.Tokens[2], 4);
            Assert.AreEqual(8, Game.Tokens[2].location);
        }

        [TestMethod()]
        public void RollDiceTest()
        {
            Assert.IsTrue(1 <= Game.Roll() && Game.Roll() <= 6);
            Assert.AreEqual(1, Game.Tokens[0].location);
            int roll = Game.Roll();
            Game.PlaceToken(Game.Tokens[0], roll);
            Assert.AreEqual(1 + roll, Game.Tokens[0].location);
        }

        [TestMethod()]
        public void PlayerWinsGame()
        {
            SnakesAndLadders Game = new SnakesAndLadders(4);
            Game.PlaceToken(Game.Tokens[0], 95);
            Assert.AreEqual(96, Game.Tokens[0].location);
            Assert.IsFalse(Game.DeclareWinner() == Game.Tokens[0].ID);
            Game.PlaceToken(Game.Tokens[0], 4);
            Assert.IsTrue(Game.DeclareWinner() == Game.Tokens[0].ID);

            Game.PlaceToken(Game.Tokens[1], 95);
            Assert.AreEqual(96, Game.Tokens[1].location);
            Assert.IsFalse(Game.DeclareWinner() == Game.Tokens[1].ID);
            Game.PlaceToken(Game.Tokens[1], 8);
            Assert.IsFalse(Game.DeclareWinner() == Game.Tokens[1].ID);
        }

        [TestMethod()]
        public void PlayerHitsSnake()
        {
            SnakesAndLadders Game = new SnakesAndLadders(4);
            Assert.AreEqual(1, Game.Tokens[0].location);
            Game.PlaceToken(Game.Tokens[0], 11);
            Assert.AreEqual(2, Game.Tokens[0].location);

            Assert.AreEqual(1, Game.Tokens[1].location);
            Game.PlaceToken(Game.Tokens[1], 1);
            Assert.AreEqual(2, Game.Tokens[1].location);
        }

        [TestMethod()]
        public void PlayerHitsLadder()
        {
            SnakesAndLadders Game = new SnakesAndLadders(4);
            Assert.AreEqual(1, Game.Tokens[0].location);
            Game.PlaceToken(Game.Tokens[0], 2);
            Assert.AreEqual(13, Game.Tokens[0].location);

            Assert.AreEqual(1, Game.Tokens[1].location);
            Game.PlaceToken(Game.Tokens[1], 12);
            Assert.AreEqual(13, Game.Tokens[1].location);
        }
    }
}