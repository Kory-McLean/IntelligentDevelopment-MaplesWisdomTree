﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using TDDKata1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TDDKata1.Tests
{
    [TestClass()]
    public class FizzBuzzTests
    {
        FizzBuzz Game = new FizzBuzz(new List<string>{"fizz","buzz","pop"}, new List<int> { 3, 5, 7});
        [TestMethod()]
        public void TestCreateFizzBuzz()
        {
            FizzBuzz Game = new FizzBuzz(new List<string> { "fizz", "buzz", "pop" }, new List<int> { 3, 5, 7 });
        }

        [TestMethod()]
        public void NormalNumbersReturnSameNumber()
        {
            Assert.AreEqual("1", Game.Play("1"));
            Assert.AreEqual("2", Game.Play("2"));
            Assert.AreEqual("4", Game.Play("4"));
        }

        [TestMethod()]
        public void MultiplesOfThreeReturnFizz()
        {
            Assert.AreEqual("fizz", Game.Play("3"));
            Assert.AreEqual("fizz", Game.Play("9"));
            Assert.AreEqual("fizz", Game.Play("123"));
        }

        [TestMethod()]
        public void MultiplesOfFiveReturnBuzz()
        {
            Assert.AreEqual("buzz", Game.Play("5"));
            Assert.AreEqual("buzz", Game.Play("20"));
            Assert.AreEqual("buzz", Game.Play("200"));
        }

        [TestMethod()]
        public void MultiplesOfBothReturnFizzBuzz()
        {
            Assert.AreEqual("fizz buzz", Game.Play("15"));
            Assert.AreEqual("fizz buzz", Game.Play("45"));
            Assert.AreEqual("fizz buzz", Game.Play("225"));
        }

        [TestMethod()]
        public void MultiplesOfSevenReturnPop()
        {
            Assert.AreEqual("pop", Game.Play("7"));
            Assert.AreEqual("pop", Game.Play("28"));
            Assert.AreEqual("pop", Game.Play("77"));
        }

        [TestMethod()]
        public void MultiplesOfFiveSevenReturnFizzBuzz()
        {
            Assert.AreEqual("fizz pop", Game.Play("21"));
            Assert.AreEqual("fizz pop", Game.Play("63"));
            Assert.AreEqual("fizz pop", Game.Play("126"));
        }

        [TestMethod()]
        public void MultiplesOfThreeSevenReturnFizzBuzz()
        {
            Assert.AreEqual("buzz pop", Game.Play("35"));
            Assert.AreEqual("buzz pop", Game.Play("70"));
            Assert.AreEqual("buzz pop", Game.Play("140"));
        }

        [TestMethod()]
        public void MultiplesOfAllReturnFizzBuzz()
        {
            Assert.AreEqual("fizz buzz pop", Game.Play("105"));
            Assert.AreEqual("fizz buzz pop", Game.Play("210"));
            Assert.AreEqual("fizz buzz pop", Game.Play("315"));
        }

        [TestMethod()]
        public void CustomVariation()
        {
            FizzBuzz Game = new FizzBuzz(new List<string> { "fuzz"}, new List<int> { 2 });
            Assert.AreEqual("1", Game.Play("1"));
            Assert.AreEqual("fuzz", Game.Play("2"));
            Assert.AreEqual("fuzz", Game.Play("8"));
            FizzBuzz CustomGame = new FizzBuzz(new List<string> { "fuzz", "bizz" }, new List<int> { 2, 3 });
            Assert.AreEqual("fuzz", CustomGame.Play("4"));
            Assert.AreEqual("bizz", CustomGame.Play("9"));
            Assert.AreEqual("fuzz bizz", CustomGame.Play("12"));
        }
    }
}