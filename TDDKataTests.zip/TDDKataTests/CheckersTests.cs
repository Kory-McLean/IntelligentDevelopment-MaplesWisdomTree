﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using TDDKata1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TDDKata1.Tests
{
    [TestClass()]
    public class CheckersTests
    {
        Checkers Game = new Checkers();
        [TestMethod()]
        public void CheckersTest()
        {
            Assert.AreEqual(8, Game.Board.Count());
        }

        [TestMethod()]
        public void TestCanJump()
        {
            Checkers.Spot Spot1 = new Checkers.Spot();
            Spot1.Occupants.Add(new Checkers.Disc("Black"));

            Checkers.Spot Spot2 = new Checkers.Spot();
            Spot2.Occupants.Add(new Checkers.Disc("Black"));

            Checkers.Spot Spot3 = new Checkers.Spot();
            Spot3.Occupants.Add(new Checkers.Disc("White"));

            Checkers.Spot Spot4 = new Checkers.Spot();

            List<Checkers.Spot> path1 = new List<Checkers.Spot> { Spot1,Spot3, Spot4 };
            List<Checkers.Spot> path2 = new List<Checkers.Spot> { Spot1,Spot2, Spot4 };
            List<Checkers.Spot> path3 = new List<Checkers.Spot> { Spot1,Spot4 };
            List<Checkers.Spot> path4 = new List<Checkers.Spot> { Spot1,Spot3, Spot4, Spot3, Spot4 };
            List<Checkers.Spot> path5 = new List<Checkers.Spot> { Spot1,Spot3, Spot3, Spot4 };



            Assert.IsTrue(Spot1.ValidPathPatternPerTeam(path1, "Black"));
            Assert.IsFalse(Spot1.ValidPathPatternPerTeam(path2, Spot1.Occupants[0].ID));
            Assert.IsTrue(Spot1.ValidPathPatternPerTeam(path3, Spot1.Occupants[0].ID));
            Assert.IsTrue(Spot1.ValidPathPatternPerTeam(path4, Spot1.Occupants[0].ID));
            Assert.IsFalse(Spot1.ValidPathPatternPerTeam(path5, Spot1.Occupants[0].ID));
        }

        [TestMethod()]
        public void TestValidMove()
        {
            Assert.IsTrue(Game.ValidMove("F1", "E2", "White"));
            Assert.IsFalse(Game.ValidMove("F1", "D3", "White"));
            Assert.IsTrue(Game.ValidMove("C2", "D3", "Black"));
            Assert.IsFalse(Game.ValidMove("C2", "E4", "Black"));
            Assert.IsTrue(Game.ValidMove("G4", "F3", "KWhite"));
            Assert.IsTrue(Game.ValidMove("G4", "F3", "KWhite"));
        }

        [TestMethod()]
        public void TestBlackCanMove()
        {
            Assert.IsTrue(Game.BlackCanMove("C4", "D5"));
            Assert.IsFalse(Game.BlackCanMove("C4", "C5"));
            Assert.IsFalse(Game.BlackCanMove("C4", "B3"));
            Assert.IsTrue(Game.BlackCanMove("C4", "D3"));
            Assert.IsTrue(Game.BlackCanMove("E2", "F1"));
            Assert.IsTrue(Game.BlackCanMove("D3", "E2"));


        }

        [TestMethod()]
        public void TestWhiteCanMove()
        {
            Assert.IsTrue(Game.WhiteCanMove("F3", "E4"));
            Assert.IsFalse(Game.WhiteCanMove("F3", "F4"));
            Assert.IsFalse(Game.WhiteCanMove("F3", "G5"));
            Assert.IsTrue(Game.WhiteCanMove("F3", "E2"));
        }

    }
}