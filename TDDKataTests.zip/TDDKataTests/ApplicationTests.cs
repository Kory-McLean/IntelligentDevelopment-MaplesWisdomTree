﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using TDDKata1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TDDKata1.Tests
{
    [TestClass()]
    public class ApplicationTests
    {
        Application Darwin = new Application("Darwin");
        [TestMethod()]
        public void CreateApplicationTest()
        {
            Application Darwin = new Application("Darwin");
        }

        [TestMethod()]
        public void AddandGetSummaryTest()
        {
            string summary = "One of Maples primary services is the provision and management of companies for our clients. We need a \nsystem that allows us to track the registers, charge fees and store key information for those companies. This is \nDarwin's job.";
            Darwin.AddSummary(summary);
            Assert.AreEqual(summary, Darwin.GetSummary());
        }

        [TestMethod]
        public void GetUserGuideLinkTest()
        {
            Darwin.SetUserGuideLink("http://moogle/IT/Guides_Manuals_and_Tips/User%20Guide%20-%20Darwin%20-%20General%20Corporate%20Administration.pdf");
            Assert.AreEqual("http://moogle/IT/Guides_Manuals_and_Tips/User%20Guide%20-%20Darwin%20-%20General%20Corporate%20Administration.pdf" ,Darwin.GetUserGuideLink());
        }
    }
}