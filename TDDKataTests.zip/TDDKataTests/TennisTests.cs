﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using TDDKata1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TDDKata1.Tests
{
    [TestClass()]
    public class TennisTests
    {
        Tennis Game = new Tennis();
        [TestMethod()]
        public void CreateTennisGameTest()
        {
            Tennis Game = new Tennis();
        }

        [TestMethod()]
        public void TestTennisPointScoredPreDeuce()
        {
            Assert.AreEqual("Score: 15-0", Game.PointScored(1));

            Assert.AreEqual("Score: 15-15", Game.PointScored(2));

            Assert.AreEqual("Score: 15-30", Game.PointScored(2));

            Assert.AreEqual("Score: 30-30", Game.PointScored(1));

            Assert.AreEqual("Score: 40-30", Game.PointScored(1));


        }

        [TestMethod()]
        public void TestTennisMatchPoint()
        {
            Game.SetScores(3, 2);
            Assert.AreEqual("Score: Winner-30", Game.PointScored(1));

            Game.SetScores(2, 3);
            Assert.AreEqual("Score: 30-Winner", Game.PointScored(2));

            Game.SetScores(4, 3);
            Assert.AreEqual("Score: Winner-40", Game.PointScored(1));

            Game.SetScores(3, 4);
            Assert.AreEqual("Score: 40-Winner", Game.PointScored(2));
        }

        [TestMethod()]
        public void TestTennisDeuceAndAdvantage()
        {
            Game.SetScores(3, 3);
            Assert.AreEqual("Score: A-40", Game.PointScored(1));

            Game.SetScores(4, 3);
            Assert.AreEqual("Score: 40-40", Game.PointScored(2));

            Game.SetScores(3, 3);
            Assert.AreEqual("Score: 40-A", Game.PointScored(2));

            Game.SetScores(3, 4);
            Assert.AreEqual("Score: 40-40", Game.PointScored(1));
        }
    }
}