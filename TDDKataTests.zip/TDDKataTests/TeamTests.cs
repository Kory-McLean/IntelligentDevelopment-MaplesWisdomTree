﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using TDDKata1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TDDKata1.Tests
{
    [TestClass()]
    public class TeamTests
    {
        Employee KQM = new Employee("Kory McLean", "June 6th", "Intern", "kory.mclean@maplesandcalder.com", "KQM");
        Employee HYS = new Employee("Hasani Stewart", "January 1st", "Intern", "hasani.stewart@maplesandcalder.com", "HYS");
        Employee GGB = new Employee("George Blake", "January 1st", "Developer", "george.blake@maplesandcalder.com", "GGB");
        Employee DUC = new Employee("David Campbell", "January 1st", "Developer", "david.campbell@maplesandcalder.com", "DUC");
        Team Raptors = new Team("Raptors");
        [TestMethod()]
        public void CreateTeamTest()
        {
            Team Tester = new Team("Tester");
        }

        [TestMethod]
        public void TestNameProperty()
        {
            Assert.AreEqual("Raptors", Raptors.GetName());
        }

        [TestMethod]
        public void MembersTest()
        {
            Assert.AreEqual(0, Raptors.GetTeamMembers().Count);
            Raptors.AddMember(KQM);
            Assert.AreEqual(1, Raptors.GetTeamMembers().Count);
            Raptors.AddMember(GGB);
            Raptors.AddMember(HYS);
            Raptors.AddMember(DUC);
            Assert.AreEqual(4, Raptors.GetTeamMembers().Count);
        }

        [TestMethod]
        public void GetTeamSummary()
        {
            Raptors.AddMember(KQM);
            Assert.AreEqual("Team Name: Raptors\nMembers:\n- Kory McLean (Intern) Email: kory.mclean@maplesandcalder.com | Alias: KQM | Birthday: June 6th", Raptors.Display());
        }

        [TestMethod]
        public void RemoveMemberTest()
        {
            Assert.AreEqual(0, Raptors.GetTeamMembers().Count);
            Raptors.AddMember(KQM);
            Assert.AreEqual(1, Raptors.GetTeamMembers().Count);
            Raptors.AddMember(GGB);
            Raptors.AddMember(HYS);
            Raptors.AddMember(DUC);
            Assert.AreEqual(4, Raptors.GetTeamMembers().Count);
            Raptors.RemoveMember("Kory McLean");
            Assert.AreEqual(3, Raptors.GetTeamMembers().Count);
            Raptors.RemoveMember("GeOrGe BlAkE");
            Assert.AreEqual(2, Raptors.GetTeamMembers().Count);
        }

        [TestMethod]
        public void FindEmployeeTest()
        {
            Raptors.AddMember(KQM);
            Raptors.AddMember(GGB);
            Raptors.AddMember(HYS);
            Raptors.AddMember(DUC);
            Assert.AreEqual(KQM, Raptors.FindEmployee("KQM"));
            Assert.AreEqual(GGB, Raptors.FindEmployee("GGB"));
            Assert.AreEqual(DUC, Raptors.FindEmployee("DUC"));
            Assert.AreEqual(null, Raptors.FindEmployee("ABC"));
        }
    }
}