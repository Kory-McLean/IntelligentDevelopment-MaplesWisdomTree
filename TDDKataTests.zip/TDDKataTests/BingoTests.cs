﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using TDDKata1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TDDKata1.Tests
{
    [TestClass()]
    public class BingoTests
    {
        Bingo Game = new Bingo();
        [TestMethod()]
        public void CreateBingoTest()
        {
            Bingo Game = new Bingo();
        }

        [TestMethod()]
        public void TestCallNumber()
        {
            int number = Game.CallNumber(1, 76);
            Assert.IsTrue(1 <= number && number <= 75);
        }


        [TestMethod()]
        public void TestAllUnique()
        {
            Assert.IsTrue(Game.TestAllUniqueHelper());
        }

        [TestMethod()]
        public void TestGenerateBingoCard()
        {
            var Card = Game.CreateCard();
            Assert.IsTrue(Game.CheckColumn("B", 1, 15, Card));
            Assert.IsTrue(Game.CheckColumn("I", 16, 30, Card));
            Assert.IsTrue(Game.CheckColumn("N", 31, 45, Card));
            Assert.IsTrue(Game.CheckColumn("G", 46, 60, Card));
            Assert.IsTrue(Game.CheckColumn("O", 61, 75, Card));
            Assert.AreEqual(25, Game.ExtractNumbers(Card).Distinct().Count());
        }

        [TestMethod()]
        public void TestPrintCard()
        {
            Bingo Game = new Bingo();
            List<List<string>> WiningCard = Game.CreateCard();
            List<List<string>> LosingCard = Game.CreateCard();
            Assert.AreEqual(89, Game.PrintCard(WiningCard).Length);
        }

        [TestMethod()]
        public void TestIsWinner()
        {
            Bingo Game = new Bingo();
            List<List<string>> WiningCard = Game.CreateCard();
            List<List<string>> LosingCard = Game.CreateCard();
            Assert.AreNotEqual(25, Game.ExtractNumbers(WiningCard).Concat(Game.ExtractNumbers(LosingCard)).Distinct().Count());
            List<int> Winner = Game.ExtractNumbers(WiningCard);
            Game.SetCalledValues(Winner);
            Assert.IsTrue(Game.DeclareWinner(WiningCard));
            Assert.IsFalse(Game.DeclareWinner(LosingCard));
        }
    }

}