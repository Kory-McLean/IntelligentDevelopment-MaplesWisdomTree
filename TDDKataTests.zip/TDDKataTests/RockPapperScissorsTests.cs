﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using TDDKata;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TDDKata.Tests
{
    [TestClass()]
    public class RockPapperScissorsTests
    {
        RockPapperScissors Game = new RockPapperScissors();
        [TestMethod()]
        public void CreateRockPapperScissorsGame()
        {
            RockPapperScissors Game = new RockPapperScissors();
        }

        [TestMethod()]
        public void TestGameRockBeatsScissors()
        {
            Assert.AreEqual("Player1 Wins.", Game.Play("rock", "scissors"));
            Assert.AreEqual("Player2 Wins.", Game.Play("scissors", "rock"));

        }

        [TestMethod()]
        public void TestScissorsBeatsPaper()
        {
            Assert.AreEqual("Player2 Wins.", Game.Play("paper", "scissors"));
            Assert.AreEqual("Player1 Wins.", Game.Play("scissors", "paper"));
        }

        [TestMethod()]
        public void TestPaperBeatsRock()
        {
            Assert.AreEqual("Player1 Wins.", Game.Play("paper", "rock"));
            Assert.AreEqual("Player2 Wins.", Game.Play("rock", "paper"));
        }

        [TestMethod()]
        public void TestIsDraw()
        {
            Assert.AreEqual("Draw", Game.Play("rock", "rock"));
            Assert.AreEqual("Draw", Game.Play("paper", "paper"));
            Assert.AreEqual("Draw", Game.Play("scissors", "scissors"));
        }

        [TestMethod()]
        public void TestPlayer1Wins()
        {
            Assert.IsTrue(Game.Player1Wins("rock", "scissors"));
            Assert.IsTrue(Game.Player1Wins("scissors", "paper"));
            Assert.IsTrue(Game.Player1Wins("paper", "rock"));
        }

        [TestMethod()]
        public void TestPlayer2Wins()
        {
            Assert.IsTrue(Game.Player2Wins("scissors", "rock"));
            Assert.IsTrue(Game.Player2Wins("paper", "scissors"));
            Assert.IsTrue(Game.Player2Wins("rock", "paper"));
        }
    }
}