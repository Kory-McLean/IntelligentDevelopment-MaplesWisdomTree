﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using TDDKata1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TDDKata1.Tests
{
    [TestClass()]
    public class GameTests
    {
        Game SSS = new Game("Super Space Shooters", "C:\\Users\\KQM\\Desktop\\Games\\SpaceShooter\\");
        [TestMethod()]
        public void CreateGameTest()
        {
            Game TesterGame = new Game("Tester", "C:/");
        }

        [TestMethod]
        public void GetGameNameTest()
        {
            Assert.AreEqual("Super Space Shooters", SSS.GetName());
        }

        [TestMethod]
        public void GetFilePath()
        {
            Assert.AreEqual("C:\\Users\\KQM\\Desktop\\Games\\SpaceShooter\\", SSS.GetFilePath());
        }
    }
}