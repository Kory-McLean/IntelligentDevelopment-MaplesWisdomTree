﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using TDDKata;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TDDKata1.Tests
{
    [TestClass()]
    public class StringCalculatorTests
    {
        StringCalculator Calculator = new StringCalculator();
        [TestMethod()]
        public void CreateStringCalculator()
        {
            StringCalculator Calculator = new StringCalculator();
        }

        [TestMethod()]
        public void TestAddEmpty()
        {
            Assert.AreEqual(0, Calculator.Add(""));
        }

        [TestMethod()]
        public void TestAddOneNumber()
        {
         Assert.AreEqual(9, Calculator.Add("9"));
        }

        [TestMethod()]
        public void TestAddMultipleNumbers()
        {
            Assert.AreEqual(15, Calculator.Add("10,5"));
            Assert.AreEqual(6, Calculator.Add("1,2,3"));
            Assert.AreEqual(2000, Calculator.Add("100,200,300,400,1000"));
        }

        [TestMethod()]
        public void TestMultipleNumbersWithNewLine()
        {
            Assert.AreEqual(6, Calculator.Add("1\n2,3"));
        }

        [TestMethod()]
        public void TestSupportDiffDelimeters()
        {
            Assert.AreEqual(3, Calculator.Add("//;\n1;2"));
        }

        [TestMethod()]
        public void TestExtractNegatives()
        {
            Assert.AreEqual("-1, -3, -10", Calculator.ExtractNegatives("-1,5,-3,9,-10"));
        }

        [TestMethod()]
        public void TestNegativeExceptionCaseWithOneNegative()
        {
            try
            {
                Calculator.Add("-1");
            }
            catch (ArgumentOutOfRangeException e)
            {
                StringAssert.Contains(e.Message, "Negatives not allowed: -1");
                return;
            }
            Assert.Fail("No exception was thrown");
        }

        [TestMethod()]
        public void TestNegativeExceptionCaseWithManyNegatives()
        {
            try
            {
                Calculator.Add("-1,5,-3,9,-10");
            }
            catch (ArgumentOutOfRangeException e)
            {
                StringAssert.Contains(e.Message, "Negatives not allowed: -1, -3, -10");
                return;
            }
            Assert.Fail("No exception was thrown");
        }

        [TestMethod()]
        public void TestLargeLengthDelimiter()
        {
            Assert.AreEqual(6, Calculator.Add("//[***]\n1***2***3"));
        }

        [TestMethod()]
        public void TestLargerThan1000()
        {
            Assert.AreEqual(2, Calculator.Add("2,1001"));
        }

        [TestMethod()]
        public void TestMultipleDelimiters()
        {
            Assert.AreEqual(6, Calculator.Add("//[*][%]\n1*2%3"));
        }

        [TestMethod()]
        public void TestMultiLengthDelimiters()
        {
            Assert.AreEqual(10, Calculator.Add("//[*][%%]{$$$]\n1*2%%3$$$4"));
        }


    }
}