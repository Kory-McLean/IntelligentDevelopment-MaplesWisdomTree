﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using TDDKata;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TDDKata.Tests
{
    [TestClass()]
    public class RomanNumeralsTests
    {
        RomanNumerals Calculator = new RomanNumerals();
        [TestMethod()]
        public void CreateRomanNumeralCalculator()
        {
            RomanNumerals Calculator = new RomanNumerals();
        }

        [TestMethod()]
        public void TestSingleTranslateToRoman()
        {
            Assert.AreEqual("I", Calculator.TranslateToRoman(1));
            Assert.AreEqual("V", Calculator.TranslateToRoman(5));
            Assert.AreEqual("L", Calculator.TranslateToRoman(50));
            Assert.AreEqual("C", Calculator.TranslateToRoman(100));
            Assert.AreEqual("D", Calculator.TranslateToRoman(500));
            Assert.AreEqual("M", Calculator.TranslateToRoman(1000));
        }

        [TestMethod()]
        public void TestLowerThanTenTranslateToRoman()
        {
            Assert.AreEqual("II", Calculator.TranslateToRoman(2));
            Assert.AreEqual("III", Calculator.TranslateToRoman(3));
        }

        [TestMethod()]
        public void TestMultipleOfFiveTranslateToRoman()
        {
            Assert.AreEqual("XV", Calculator.TranslateToRoman(15));
            Assert.AreEqual("XXV", Calculator.TranslateToRoman(25));
            Assert.AreEqual("LI", Calculator.TranslateToRoman(51));
            Assert.AreEqual("LXX", Calculator.TranslateToRoman(70));
            Assert.AreEqual("MDLV", Calculator.TranslateToRoman(1555));
            Assert.AreEqual("DCCLXVII", Calculator.TranslateToRoman(767));
            Assert.AreEqual("CM", Calculator.TranslateToRoman(900));

        }

        [TestMethod()]
        public void TestToRomanCases()
        {
            Assert.AreEqual("MCMLXXXIX", Calculator.TranslateToRoman(1989));
            Assert.AreEqual("MLXVI", Calculator.TranslateToRoman(1066));
            Assert.AreEqual("IX", Calculator.TranslateToRoman(9));
            Assert.AreEqual("III", Calculator.TranslateToRoman(3));
            Assert.AreEqual("I", Calculator.TranslateToRoman(1));
        }
        //-----------------------To Arabic-----------------------------------------

        [TestMethod()]
        public void TestGetArabicValue()
        {
            Assert.AreEqual(Calculator.GetArabicValue("M"), 1000);
            Assert.AreEqual(Calculator.GetArabicValue("X"), 10);
            Assert.AreEqual(Calculator.GetArabicValue("V"), 5);
            Assert.AreEqual(Calculator.GetArabicValue("IX"), 9);
            Assert.AreEqual(Calculator.GetArabicValue("A"), 0);
        }

        [TestMethod()]
        public void TestFinal()
        {
            Assert.AreEqual(1 ,Calculator.Calculate("I"));
            Assert.AreEqual(3, Calculator.Calculate("III"));
            Assert.AreEqual(9, Calculator.Calculate("IX"));
            Assert.AreEqual(1066, Calculator.Calculate("MLXVI"));
            Assert.AreEqual(1989, Calculator.Calculate("MCMLXXXIX"));

        }
    }
}