﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using TDDKata1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TDDKata1.Tests
{
    [TestClass()]
    public class LudoGameTests
    {
        LudoGame Game = new LudoGame(4);
        [TestMethod()]
        public void CreateLudoGameTest()
        {
            Assert.AreEqual(4, Game.Players.Count());
        }
    }
}