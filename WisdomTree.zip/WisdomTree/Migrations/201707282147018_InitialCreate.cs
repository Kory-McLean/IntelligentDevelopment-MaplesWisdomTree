namespace WisdomTree.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitialCreate : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Employees",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        Name = c.String(maxLength: 60),
                        Birthday = c.DateTime(),
                        Position = c.String(maxLength: 40),
                        Availability = c.String(maxLength: 20),
                        Email = c.String(),
                        Alias = c.String(maxLength: 3),
                        Team = c.String(maxLength: 40),
                        Employee_ID = c.Int(),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.Employees", t => t.Employee_ID)
                .Index(t => t.Employee_ID);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Employees", "Employee_ID", "dbo.Employees");
            DropIndex("dbo.Employees", new[] { "Employee_ID" });
            DropTable("dbo.Employees");
        }
    }
}
