namespace WisdomTree.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class updateFix : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Employees", "Employee_ID", "dbo.Employees");
            DropIndex("dbo.Employees", new[] { "Employee_ID" });
            AlterColumn("dbo.Applications", "Name", c => c.String(nullable: false, maxLength: 60));
            AlterColumn("dbo.Applications", "UserGuideLink", c => c.String(nullable: false));
            AlterColumn("dbo.Games", "GameLink", c => c.String(nullable: false));
            AlterColumn("dbo.Games", "Title", c => c.String(nullable: false, maxLength: 60));
            AlterColumn("dbo.Quotes", "QuoteString", c => c.String(nullable: false));
            AlterColumn("dbo.Quotes", "Author", c => c.String(nullable: false));
            DropColumn("dbo.Employees", "Employee_ID");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Employees", "Employee_ID", c => c.Int());
            AlterColumn("dbo.Quotes", "Author", c => c.String());
            AlterColumn("dbo.Quotes", "QuoteString", c => c.String());
            AlterColumn("dbo.Games", "Title", c => c.String());
            AlterColumn("dbo.Games", "GameLink", c => c.String());
            AlterColumn("dbo.Applications", "UserGuideLink", c => c.String());
            AlterColumn("dbo.Applications", "Name", c => c.String());
            CreateIndex("dbo.Employees", "Employee_ID");
            AddForeignKey("dbo.Employees", "Employee_ID", "dbo.Employees", "ID");
        }
    }
}
