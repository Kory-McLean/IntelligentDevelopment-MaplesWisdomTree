namespace WisdomTree.Migrations
{
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;
    using WisdomTree.Models;
    using System.Collections.Generic;

    internal sealed class Configuration : DbMigrationsConfiguration<WisdomTree.Data.Context.WisdomTreeContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
            ContextKey = "WisdomTree.Models.EmployeeDBContext";
        }

        protected override void Seed(WisdomTree.Data.Context.WisdomTreeContext context)
        {
            context.Employees.AddOrUpdate(i => i.Name,
       new Employee
       {
           Name = "Kory McLean",
           Position = "Intern",
           Birthday = DateTime.Parse("1998-6-6"),
           Team = "Raptors",
           Availability = "Available",
           Email = "kory.mclean@maplesandcalder.com",
           Alias = "KQM",
           Hobbies = new List<string>() { "football", "videogames" }
       },
        new Employee
        {
            Name = "Hasani Stewart",
            Position = "Intern",
            Birthday = DateTime.Parse("1998-6-6"),
            Team = "Raptors",
            Availability = "Available",
            Email = "hasani.stewart@maplesandcalder.com",
            Alias = "HYS"
        },
        new Employee
        {
        Name = "George Blake",
        Position = "Developer",
        Birthday = DateTime.Parse("1998-7-6"),
        Team = "Raptors",
        Availability = "Available",
        Email = "george.blake@maplesandcalder.com",
        Alias = "GGB"
        },
        new Employee
        {
        Name = "David Campbell",
        Position = "Developer",
        Birthday = DateTime.Parse("1998-6-6"),
        Team = "Raptors",
        Availability = "Available",
        Email = "david.campbell@maplesandcalder.com",
        Alias = "DUC"
        },

        new Employee
        {
        Name = "Tom Chipchase",
        Position = "Senior Software Developer",
        Birthday = DateTime.Parse("1998-6-6"),
        Team = "Vipers",
        Availability = "Available",
        Email = "tom.chipchase@maplesandcalder.com",
        Alias = "TCC"
        }
        );

            context.Quotes.AddOrUpdate(i => i.QuoteString,
                new Quote
                {
                    QuoteString = "You can't be paralyzed by fear of failure or you will never push yourself.",
                    Author = "Arnold Schwarzenegger"
                },

                new Quote
                {
                    QuoteString = "Once you replace negative thoughts with positive ones, you'll start having positive results.",
                    Author = "Willie Nelson"
                },

                   new Quote
                   {
                       QuoteString = "A year from now you will wish you had started today.�",
                       Author = "Karen Lamb"
                   }
                );

            context.Games.AddOrUpdate(i => i.Title,

                new Game
                {
                    Title = "Frogger",
                    GameLink = "C:\\Users\\KQM\\Desktop\\Games\\Frogger\\indexEasy.html"
                },

                new Game
                {
                    Title = "Blaster Fight",
                    GameLink = "C:\\Users\\KQM\\Desktop\\Games\\BlasterFight\\IndexBF.html"
                },

                new Game
                {
                    Title = "Super Space Shooters",
                    GameLink = "C:\\Users\\KQM\\Desktop\\Games\\SpaceShooter\\indexSS.html"
                }
                );

            context.Applications.AddOrUpdate(i => i.Name,

                new Application
                {
                    Name = "Darwin",
                    UserGuideLink = "http://moogle/IT/Guides_Manuals_and_Tips/User%20Guide%20-%20Darwin%20-%20General%20Corporate%20Administration.pdf",
                    Summary = "One of Maples primary services is the provision and management of companies for our clients. We need a \nsystem that allows us to track the registers, charge fees and store key information for those companies. This is Darwin's job."
                });

            context.Accounts.AddOrUpdate(i => i.Username,

                new Account
                {
                    Username = "KQM",
                    Password = "Kory",
                });
        }
    }
}
