namespace WisdomTree.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ApplicationsAdded : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Applications",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        Name = c.String(),
                        UserGuideLink = c.String(),
                        Summary = c.String(),
                    })
                .PrimaryKey(t => t.ID);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.Applications");
        }
    }
}
