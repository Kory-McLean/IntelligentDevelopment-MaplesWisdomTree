﻿using System.Collections.Generic;
using WisdomTree.Models;
using WisdomTree.Data.Repos;
using System.Web.Mvc;

namespace WisdomTree.Services
{
	public class AccountService
	{
		AccountRepository accountRepository = new AccountRepository();

		public Account GetAccount(int? id)
		{
			return accountRepository.GetAccount(id);
		}

		public Account GetAccountByUserName(string username)
		{
			return accountRepository.GetAccountByUsername(username)[0];
		}

		public List<Account> GetAccounts()
		{
			return accountRepository.GetAccounts();
		}

		public bool VerifyLogIn(string username, string password)
		{
			return accountRepository.VerifyLogIn(username, password);
		}

		internal bool VerifySignUp(string username, string password1, string password2)
		{
			return accountRepository.VerifySignUp(username, password1, password2);
		}

		public void AddAcount(string username, string password1)
		{
			accountRepository.AddAcount(username, password1);
		}

		public SelectList GetProfileOptions()
		{
			return accountRepository.GetProfileOptions();
		}

		public bool VerifyResetPassword(string username, string curPassword, string password1, string password2)
		{
			return accountRepository.VerifyResetPassword(username, curPassword, password1, password2);
		}

		public void ResetPassword(string username, string password1)
		{
			accountRepository.ResetPassword(username, password1);
		}

		public void DeleteAccount(string username)
		{
			accountRepository.DeleteAccount(GetAccountByUserName(username));
		}

		public List<string> GetUsernames()
		{
			return accountRepository.GetUsernames();
		}
	}
}