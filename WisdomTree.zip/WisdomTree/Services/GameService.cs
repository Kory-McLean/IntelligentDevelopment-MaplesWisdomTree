﻿using System.Web;
using WisdomTree.Models;
using WisdomTree.Controllers;
using System.Data.Entity;
using System.Web.Mvc;
using System.Data;
using WisdomTree.Data.Repos;
using System;
using System.Collections.Generic;
using System.Linq;

namespace WisdomTree.Services
{
    public class GameService
    {
        GameRepository gameRepository = new GameRepository();

        public List<Game> GetGames()
        {
            return gameRepository.GetGames();
        }

        public List<string> GetTitles()
        {
            return gameRepository.GetTitles();
        }

        public List<Game> SearchGame(string title)
        {
            return gameRepository.SearchGame(title);
        }

        public void OpenGame(int? id)
        {
            gameRepository.OpenGame(id);
        }

        public GamePageModel GetGamePage(string searchTitle=null)
        {
            var model = new GamePageModel();
            model.Games = SearchGame(searchTitle);

            return model;
        }
    }
}