﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WisdomTree.Models;
using WisdomTree.Controllers;
using System.Data.Entity;
using System.Web.Mvc;
using System.Data;
using WisdomTree.Data.Repos;

namespace WisdomTree.Services
{
    public class ApplicationService
    {
        ApplicationRepository applicationRepository = new ApplicationRepository();
        public List<Application> GetApplications()
        {
            return applicationRepository.GetApplications();
        }

        public List<Application> SearchApplicaitonByName(string name)
        {
            return applicationRepository.SearchApplicationByName(name);
        }

        public List<string> GetApplicationNames()
        {
            return applicationRepository.GetApplicationNames();
        }
        public ApplicationPageModel GetApplicationPage(string name)
        {
            var model = new ApplicationPageModel();
            model.Applications = SearchApplicaitonByName(name);
            model.Names = GetApplicationNames();

            return model;
        }

        public void OpenApplicationGuide(int? id)
        {
            applicationRepository.OpenApplicationGuide(id);
        }
    }
}