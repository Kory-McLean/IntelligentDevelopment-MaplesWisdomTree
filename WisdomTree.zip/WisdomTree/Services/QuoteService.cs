﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WisdomTree.Models;
using WisdomTree.Controllers;
using System.Data.Entity;
using System.Web.Mvc;
using System.Data;
using WisdomTree.Data.Repos;


namespace WisdomTree.Services
{
	public class QuoteService
	{

		public QuoteRepository quoteRepository = new QuoteRepository();

		public Quote GetQuoteOfTheDay()
		{
			return quoteRepository.GetQuoteOfTheDay();
		}

		public List<string> GetAuthors()
		{
			return quoteRepository.GetAuthors();
		}

		public List<Quote> GetQuotesByAuthor(string author)
		{
			return quoteRepository.GetQuotesByAuthor(author);
		}
	}
}