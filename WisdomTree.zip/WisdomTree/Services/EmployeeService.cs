﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WisdomTree.Models;
using WisdomTree.Controllers;
using System.Data.Entity;
using System.Web.Mvc;
using System.Data;
using WisdomTree.Data.Repos;

namespace WisdomTree.Services
{
    public class EmployeeService
    {
        EmployeeRepository employeeRepository = new EmployeeRepository();
        QuoteService quoteService = new QuoteService();

        public List<Employee> GetEmployees(string searchString = null, string employeeTeam = null)
        {
            var employees = from e in employeeRepository.db.Employees
                            select e;

            if (!string.IsNullOrEmpty(employeeTeam))
            {
                employees = employees.Where(x => x.Team == employeeTeam);
            }

            return employees.ToList();
        }

        public List<Employee> SearchEmployeesByNameAndAlias(string searchTerm)
        {
            return employeeRepository.SearchEmployeesByNameAndAlias(searchTerm).ToList();
        }

        public List<Employee> SearchEmployeesByTeam(string searchTeam)
        {
            return employeeRepository.SearchEmployeesByTeam(searchTeam).ToList();
        }

        public List<Employee> CompleteEmployeeSearch(string searchTerm, string team)
        {
            return employeeRepository.CompleteSearchResults(searchTerm, team);
        }

        public List<String> GetTeams()
        {
            return employeeRepository.GetTeams();
        }

        public EmployeePageModel GetEmployeePage(string team, string searchTerm)
        {
            var model = new EmployeePageModel();

            model.Quote = quoteService.GetQuoteOfTheDay();
            model.Employees = CompleteEmployeeSearch(searchTerm, team);
            model.Teams = GetTeams();

            return model;
        }
    }
}