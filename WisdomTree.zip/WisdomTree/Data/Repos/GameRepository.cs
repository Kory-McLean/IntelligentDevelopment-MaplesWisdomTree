﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WisdomTree.Models;
using WisdomTree.Data.Context;


namespace WisdomTree.Data.Repos
{
    public class GameRepository
    {
        public WisdomTreeContext db = new WisdomTreeContext();

        public List<Game> GetGames()
        {
            var games = from g in db.Games
                         select g;
            return games.ToList();
        }

        public List<Game> SearchGame(string title)
        {
            var games = from g in db.Games
                        select g;

            if (!String.IsNullOrEmpty(title))
            {
                return games.Where(g => g.Title.Contains(title)).ToList();
            }

            return games.ToList();
           
        }

        public List<string> GetTitles ()
        {
            var TitleLst = new List<string>();

            var TitleQry = from d in db.Games
                          orderby d.Title
                          select d.Title;

            TitleLst.AddRange(TitleQry.Distinct());
            return TitleLst;
        }

        public Game FindGame(int? id)
        {
            foreach (Game game in db.Games)
            {
                if (game.ID == id)
                {
                    return game;
                }
            }
            return null;
        }

        public void OpenGame(int? id)
        {
            if (FindGame(id) != null)
            {
                System.Diagnostics.Process.Start(FindGame(id).GameLink);
            }
        }
    }
}
