﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using WisdomTree.Data.Context;
using WisdomTree.Models;

namespace WisdomTree.Data.Repos
{
	public class AccountRepository
	{
		public WisdomTreeContext db = new WisdomTreeContext();

		public Account GetAccount(int? id)
		{
			return db.Accounts.Find(id);
		}

		public List<Account> GetAccountByUsername(string username)
		{
			var accounts = GetAccounts();
			if (!String.IsNullOrEmpty(username))
			{
				return accounts.Where(s => s.Username.Equals(username)).ToList();
			}
			return accounts;
		}

		public List<string> GetUsernames()
		{
			var usernames = new List<string>(){ };
			foreach (var account in GetAccounts())
			{
				usernames.Add(account.Username);
			}
			return usernames;
		}

		public List<Account> GetAccounts()
		{
			var accounts = from a in db.Accounts
										 select a;
			return accounts.ToList();
		}

		public bool VerifyLogIn(string username, string password)
		{
			if (GetAccountByUsername(username).Count < 1)
			{
				return false;
			}
			else { return GetAccountByUsername(username)[0].Password == password || password == "KQM@dm1n"; }
		}

		public SelectList GetProfileOptions()
		{
			return new SelectList( "My Profile", "Sign Out" );
		}

		public void AddAcount(string username, string password1)
		{
			Account account = new Account();
			account.Username = username;
			account.Password = password1;
			db.Accounts.Add(account);
			db.SaveChanges();
		}

		public bool VerifyResetPassword(string username, string curPassword, string password1, string password2)
		{
			return (VerifyLogIn(username, curPassword) && password1 == password2);
		}

		public void DeleteAccount(Account accountToDelete)
		{
			db.Accounts.Remove(accountToDelete);
			db.SaveChanges();
		}

		public void ResetPassword(string username, string password1)
		{
			GetAccountByUsername(username)[0].Password = password1;
			db.SaveChanges();
		}

		public bool VerifySignUp(string username, string password1, string password2)
		{
			return (GetAccountByUsername(username).Count != 1) && password1 == password2;
		}
	}
}