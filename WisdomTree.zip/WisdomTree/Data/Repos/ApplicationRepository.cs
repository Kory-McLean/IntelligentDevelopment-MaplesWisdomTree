﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WisdomTree.Data.Context;
using WisdomTree.Models;

namespace WisdomTree.Data.Repos
{
    public class ApplicationRepository
    {
        public WisdomTreeContext db = new WisdomTreeContext();

        public List<Application> GetApplications()
        {
            var applicaiton = from a in db.Applications
                            select a;
            return applicaiton.ToList();
        }

        public List<Application> SearchApplicationByName(string name)
        {
            var application = GetApplications();
            if (!String.IsNullOrEmpty(name))
            {
                return application.Where(s => s.Name.Contains(name)).ToList();
            }

            return application.ToList();
        }

        public Application FindApplication(int? id)
        {
            foreach (Application application in db.Applications)
            {
                if (application.ID == id)
                {
                    return application;
                }
            }
            return null;
        }

        public List<string> GetApplicationNames()
        {
                var NameLst = new List<string>();

                var NameQry = from a in db.Applications
                              orderby a.Name
                              select a.Name;

                NameLst.AddRange(NameQry.Distinct());
                return NameLst;
        }

        public void OpenApplicationGuide(int? id)
        {
            if (FindApplication(id) != null)
            {
                System.Diagnostics.Process.Start(FindApplication(id).UserGuideLink);
            }
        }


    }
}