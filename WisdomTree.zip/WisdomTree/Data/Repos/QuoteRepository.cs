﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WisdomTree.Data.Context;
using WisdomTree.Models;

namespace WisdomTree.Data.Repos
{
	public class QuoteRepository
	{
		public WisdomTreeContext db = new WisdomTreeContext();

		public List<Quote> GetQuotes()
		{
			var TeamLst = new List<string>();

			//var TeamQry = from d in db.Employees
			//							orderby d.Team
			//							select d.Team;

			//TeamLst.AddRange(TeamQry.Distinct());
			//return TeamLst;

			var quotes = from q in db.Quotes
									 select q;
			return quotes.ToList();
		}

		public List<Quote> GetQuotesByAuthor(string author)
		{
			var quotes = GetQuotes();

			if (!String.IsNullOrEmpty(author))
			{
				return quotes.Where(s => s.Author == author).ToList();
			}

			return quotes;
		}

		public Quote GetQuoteOfTheDay()
		{
			Random rnd = new Random();
			return GetQuotes()[rnd.Next(0, GetQuotes().Count())];
		}

		public List<string> GetAuthors()
		{
			var authors = new List<string>() { };
			foreach (var quote in GetQuotes())
			{
				if (!authors.Contains(quote.Author))
				{
					authors.Add(quote.Author);
				}
			}
			authors.Sort();
			return authors;
		}
	}
}