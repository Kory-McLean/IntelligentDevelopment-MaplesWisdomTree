﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WisdomTree.Data.Context;
using WisdomTree.Models;

namespace WisdomTree.Data.Repos
{
    public class EmployeeRepository
    {
        public WisdomTreeContext db = new WisdomTreeContext();

        public List<Employee> GetEmployees()
        {
            var employees = from e in db.Employees
                            select e;

            return employees.ToList();
        }

        public List<Employee> SearchEmployeesByNameAndAlias(string searchTerm)
        {
            var employees = GetEmployees();

            if (!String.IsNullOrEmpty(searchTerm))
            {
                return employees.Where(s => s.Name.Contains(searchTerm) || s.Alias.ToLower() == searchTerm.ToLower()).ToList();
            }

            return employees;
        }

        public List<Employee> SearchEmployeesByTeam(string team)
        {
            var employees = GetEmployees();

            if (!String.IsNullOrEmpty(team))
            {
                return employees.Where(s => s.Team.Contains(team)).ToList();
            }

            return employees.ToList();
        }

        public List<Employee> CompleteSearchResults(string searchTerm, string team)
        {
            var employeesByNameAndAlias = SearchEmployeesByNameAndAlias(searchTerm);
            var employeesByTeam = SearchEmployeesByTeam(team);
            var employeesAll = GetEmployees();

            return employeesAll.Where(e => employeesByNameAndAlias.Contains(e) && employeesByTeam.Contains(e)).ToList();
        }

        public List<string> GetTeams()
        {
            var TeamLst = new List<string>();

            var TeamQry = from d in db.Employees
                          orderby d.Team
                          select d.Team;

            TeamLst.AddRange(TeamQry.Distinct());
            return TeamLst;
        }
    }
}