﻿using System.Data.Entity;
using WisdomTree.Models;

namespace WisdomTree.Data.Context
{
    public class WisdomTreeContext : DbContext
    {
        public DbSet<Employee> Employees { get; set; }

        public DbSet<Quote> Quotes { get; set; }

        public DbSet<Game> Games { get; set; }

        public DbSet<Application> Applications { get; set; }

        public DbSet<Account> Accounts { get; set; }
    }
}