﻿using System.ComponentModel.DataAnnotations;

namespace WisdomTree.Models
{
	public class SignUpViewModel
	{
		[Required]
		public string Username { get; set; }

		[Required]
		public string Password { get; set; }

		[Required]
		[Display(Name = "Password Confirmation")]
		public string PasswordConfirmation { get; set; }
	}
}