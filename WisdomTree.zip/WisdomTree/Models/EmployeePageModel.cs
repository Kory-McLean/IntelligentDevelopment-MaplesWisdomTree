﻿using System.Collections.Generic;

namespace WisdomTree.Models
{
    public class EmployeePageModel
    {
        public Quote Quote { get; set; }
        public List<Employee> Employees{get;set;}
        public List<string> Teams { get; set; }
    }
}