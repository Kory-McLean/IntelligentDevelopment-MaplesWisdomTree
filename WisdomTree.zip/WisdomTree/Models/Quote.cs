﻿using System.ComponentModel.DataAnnotations;

namespace WisdomTree.Models
{
	public class Quote
	{
		public int ID { get; set; }

		[Required]
		[Display(Name = "Quote")]
		public string QuoteString { get; set; }

		[Required]
		public string Author { get; set; }
		public string DisplayQuote => $"\"{QuoteString}\" - {Author}";
	}
}