﻿namespace WisdomTree.Models
{
	public class DeleteViewPageModel
	{
		public Account account { get; set; }
	}
}