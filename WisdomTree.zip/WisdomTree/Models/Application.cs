﻿using System.ComponentModel.DataAnnotations;

namespace WisdomTree.Models
{
	public class Application
	{
		public int ID { get; set; }

		[StringLength(60, MinimumLength = 3)]
		[Required]
		public string Name { get; set; }

		[Display(Name = "User-Guide Link")]
		[Required]
		public string UserGuideLink { get; set; }


		public string Summary { get; set; }
	}
}