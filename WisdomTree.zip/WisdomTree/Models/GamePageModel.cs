﻿using System.Collections.Generic;

namespace WisdomTree.Models
{
    public class GamePageModel
    {
        public List<Game> Games { get; set; }
        public List<string> Titles { get; set; }
    }
}
