﻿using System.ComponentModel.DataAnnotations;

namespace WisdomTree.Models
{
	public class ResetPasswordViewModel
	{
		[Required]
		public string Username { get; set; }

		[Required]
		[Display(Name = "Current Password")]
		public string CurrentPassword { get; set; }

		[Required]
		public string Password { get; set; }

		[Required]
		[Display(Name = "Password Confirmation")]
		public string PasswordConfirmation { get; set; }
	}
}