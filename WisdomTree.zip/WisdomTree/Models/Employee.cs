﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace WisdomTree.Models
{
    public class Employee
    {
        public int ID { get; set; }

        [StringLength(60, MinimumLength = 3)]
        public string Name { get; set; }

        [Display(Name = "Birthday")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime? Birthday { get; set; }

        [RegularExpression(@"^[A-Z]+[a-zA-Z''-'\s]*$")]
        [StringLength(40, MinimumLength = 3)]
        public string Position { get; set; }

        [StringLength(20, MinimumLength = 3)]
        public string Availability { get; set; }

        public List<string> Hobbies = new List<string>() { };

        public string Email { get; set; }

        [StringLength(3, MinimumLength = 3)]
        public string Alias { get; set; }

        //public List<Employee> Besties { get; set; }

        [RegularExpression(@"^[A-Z]+[a-zA-Z''-'\s]*$")]
        [StringLength(40, MinimumLength = 3)]
        public string Team { get; set; }
    }
}