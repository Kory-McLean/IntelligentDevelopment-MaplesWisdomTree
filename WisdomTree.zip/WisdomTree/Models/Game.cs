﻿using System.ComponentModel.DataAnnotations;

namespace WisdomTree.Models
{
	public class Game
	{
		public int ID { get; set; }

		[Display(Name = "Link to Game File")]
		[Required]
		public string GameLink { get; set; }

		[StringLength(60, MinimumLength = 3)]
		[Required]
		public string Title { get; set; }
	}
}