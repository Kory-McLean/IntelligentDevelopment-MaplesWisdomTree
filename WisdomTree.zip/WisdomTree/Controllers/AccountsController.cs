﻿using System.Web.Mvc;
using WisdomTree.Models;
using WisdomTree.Services;
using WisdomTree.Data.Context;
using System.Web.Security;

namespace WisdomTree.Controllers
{
	public class AccountsController : Controller
	{
		WisdomTreeContext db = new WisdomTreeContext();
		AccountService accountService = new AccountService();

		public ActionResult Login()
		{
			System.Web.HttpContext.Current.Session["currentUser"] = "Guest";
			return View("Login");
		}

		[HttpPost]
		public ActionResult Login(LogInViewModel login)
		{
		if (!ModelState.IsValid)
			{
				ViewBag.Error = "Form is not valid; please review and try again.";
				return View("Login");
			}

			if (accountService.VerifyLogIn(login.Username, login.Password))
			{
				System.Web.HttpContext.Current.Session["currentUser"] = login.Username;
				return RedirectToAction("LaunchPage", "LaunchPage");
			}
			else if (!accountService.GetUsernames().Contains(login.Username))
			{
				ModelState.AddModelError("Username", "Username Not Found.");
				return View(login);
			}
			else if (!accountService.VerifyLogIn(login.Username, login.Password))
			{
				ModelState.AddModelError("Password", "Incorrect Password, If you do not remember your password you can reset it below.");
				return View(login);
			}
			else
			{
				return View(login);
			}
		}

		public ActionResult LogOut()
		{
			Session.Clear();
			FormsAuthentication.SignOut();
			return RedirectToAction("Login");
		}

		public ActionResult SignUp()
		{
			return View("SignUp");
		}

		[HttpPost]
		public ActionResult SignUp(SignUpViewModel signUp)
		{
			if (!ModelState.IsValid)
			{
				ViewBag.Error = "Form is not valid; please review and try again.";
				return View("SignUp");
			}

			if (accountService.VerifySignUp(signUp.Username, signUp.Password, signUp.PasswordConfirmation))
			{
				accountService.AddAcount(signUp.Username, signUp.Password);
				return RedirectToAction("Login");
			}
			else if (accountService.GetUsernames().Contains(signUp.Username))
			{
				ModelState.AddModelError("Username", "Sign Up Failed, Your Desired Username is Already taken, Please select another one.");
				return View(signUp);
			}
			else if(signUp.Password != signUp.PasswordConfirmation)
			{
				ModelState.AddModelError("PasswordConfirmation", "Sign Up Failed, Your Passwords do not match!");
				return View(signUp);
			}
			return View(signUp);
		}


		public ActionResult ResetPassword()
		{
			return View("ResetPassword");
		}

		[HttpPost]
		public ActionResult ResetPassword(ResetPasswordViewModel resetPassword)
		{
			if (!ModelState.IsValid)
			{
				ViewBag.Error = "Form is not valid; please review and try again.";
				return View("SignUp");
			}

			if (accountService.VerifyResetPassword(resetPassword.Username, resetPassword.CurrentPassword, resetPassword.Password, resetPassword.PasswordConfirmation))
			{
				accountService.ResetPassword(resetPassword.Username, resetPassword.Password);
				return RedirectToAction("Login");
			}

			else if (!accountService.GetUsernames().Contains(resetPassword.Username))
			{
				ModelState.AddModelError("Username", "Username Not Found.");
				return View(resetPassword);
			}
			else if(!accountService.VerifyLogIn(resetPassword.Username, resetPassword.CurrentPassword))
			{
				ModelState.AddModelError("CurrentPassword", "Incorrect Current Password.");
				return View(resetPassword);
			}
			else if(resetPassword.Password != resetPassword.PasswordConfirmation)
			{
				ModelState.AddModelError("PasswordConfirmation", "Your Passwords Do Not Match");
				return View(resetPassword);
			}
			else
			{
				return View(resetPassword);
			}
		}

		public ActionResult Support()
		{
			System.Diagnostics.Process.Start("C:\\ProgramData\\Microsoft\\Windows\\Start Menu\\Programs\\Outlook 2016");
			return View("Login");
		}

		public ActionResult Delete(string username, string password)
		{
				return View("Delete");
		}

		[HttpPost]
		public ActionResult Delete(DeleteViewPageModel delete)
		{
			if (!ModelState.IsValid)
			{
				ViewBag.Error = "Form is not valid; please review and try again.";
				return View("Delete");
			}
			if (accountService.VerifyLogIn(delete.account.Username, delete.account.Password))
			{
				accountService.DeleteAccount(delete.account.Username);
				return RedirectToAction("Login");
			}
			else if (!accountService.GetUsernames().Contains(delete.account.Username))
			{
				ModelState.AddModelError("account.Username", "Username Not Found");
				return View(delete);
			}
			else if (!accountService.VerifyLogIn(delete.account.Username, delete.account.Password))
			{
				ModelState.AddModelError("account.Password", "Incorrect Password, If you do not remember your password you can reset it below or contact the Admin");
				return View(delete);
			}
			else
			{
				return View(delete);
			}
		}
	}
}