﻿using System.Web.Mvc;
namespace MvcMovie.Controllers
{
    public class NavBarController : Controller
    {
        public ActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public ActionResult Error()
        {
            return View();
        }

        public ActionResult Wiki()
        {
            System.Diagnostics.Process.Start("http://devwiki/dashboard.action;jsessionid=2337FC6E7DC08522D8EB681EAA9300AB");
            return View();
        }

        public ActionResult Email()
        {
            System.Diagnostics.Process.Start("C:\\ProgramData\\Microsoft\\Windows\\Start Menu\\Programs\\Outlook 2016");
            return View();
        }
    }
}
