﻿using System.Data.Entity;
using System.Net;
using System.Web.Mvc;
using WisdomTree.Models;
using WisdomTree.Services;
using WisdomTree.Data.Context;

namespace WisdomTree.Controllers
{
    public class GamesController : Controller
    {
        public WisdomTreeContext db = new WisdomTreeContext();

        GameService gameService = new GameService();
        // GET: Games
        public ActionResult GamePage(string searchTitle = null)
        {
            return View(gameService.GetGamePage(searchTitle));
        }

        public ActionResult OpenGame(int? id)
        {
            gameService.OpenGame(id);
            return View();
        }

        // GET: Employees/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Game game = db.Games.Find(id);
            if (game == null)
            {
                return HttpNotFound();
            }
            return View(game);
        }

        // POST: Employees/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ID,Title,GameLink")] Game game)
        {
            if (ModelState.IsValid)
            {
                db.Entry(game).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("GamePage", "Games");
            }
            return View(game);
        }
    }
}