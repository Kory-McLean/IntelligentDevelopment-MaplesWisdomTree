﻿using System.Web.Mvc;

namespace WisdomTree.Controllers
{
    public class LaunchPageController : Controller
    {
        // GET: LaunchPage
        public ActionResult LaunchPage()
        {
            return View();
        }
    }
}